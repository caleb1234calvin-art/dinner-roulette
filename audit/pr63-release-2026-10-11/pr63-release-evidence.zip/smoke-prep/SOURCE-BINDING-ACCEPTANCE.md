# PR63 served-source acceptance — PASS

Deployment supplied by authenticated root release operator: `dpl_7MmWVLGr9roCmWit3yzASutdRZGs`, exact source `f92870632b71def18d7642596dc9dd3357675f76`, tree `9153ead1946bbbb7e38c45981c47332997001c3e`. This worker independently captured public apex and immutable deployment outputs; root separately owns metadata/source/build-route/alias and live-UI acceptance.

The complete60 catalog data literals served by `/assets/index-Bp9wA5ps.js` deep-equal exact approved Git source. All60 consumer presentation objects served by `/assets/routes-Daqqcx29.js` also deep-equal. All59 previous raw catalog objects remain unchanged; Goblin is the sole new identity. Brookdale and Hotel are the only two prior presentation amendments; the other57 remain unchanged. Canonical IDs are unique; Hotel/Dungeons remain separately addressed, and Werehouse legacy availability remains exact-source equal.

Public apex and `https://dinner-roulette-a3n6j3i8n-minions-9e2c.vercel.app/` return the same seven application entry JS assets with identical bytes. The same-origin telemetry script was also captured with identical transport bytes, but excluded from application data parsing. The external Grok extension script was explicitly not fetched. Final capture used18 GETs (two HTML pages plus eight directly referenced same-origin JS files per origin); no provider queries, browser execution, clock changes or product mutation occurred.

Goblin's exact eight supported dates, partial hours, operator-linked approximate placement, visitor-address Directions and date-only cutoff2026-10-25T05:00:00Z survive unchanged. Brookdale keeps November8 18:00CST cutoff, exact original address and separate-admission/October-calendar note. Hotel keeps its own address and combo-transfer note; Dungeons keeps its separate address and unchanged projection. Every selected row retains null machine hours, never-OpenNow and2026 year bounds.

Future-date/cache/no2027 acceptance is source-bound to the retained independently verified exact-head evidence, not a live-clock experiment: Web38107379751; selected raw browser artifact11690219093 with87/87 scenarios; raw verdict SHA256 `b6af0bc61f5e7f844c237043e3e9a16dfc128d10936fdb02bca683b242b598dc`. The retained independent reviewer explicitly inspected each selected row's exact-cutoff local cache, actual held RPC crossing expiry, direct Favorites reload, provider/alias duplicates, negative preferences, no2027 scenario and full navigation/copy. `exact-head-evidence-links.json` pins those reports and exact source locations.

Published catalog count is60. At the captured current time,57 have not passed their listing cutoffs and three prior records expired normally onOctober10: Christine’s Vineyard Witches Day Out, Nevada/Vernon County Oktoberfest and Osage Beach City Park Fall Festival. That57 is a cutoff inventory, not a claim all57 are currently open, within a user's radius, or eligible under every filter. Allthree selected records remain before their cutoffs.

## Files to preserve

- `production-source-binding.json`: complete verified comparison receipt.
- `served-assets-download.json`: original URL/status/header/byte/hash capture receipts.
- `production-index.html`, `immutable-index.html`, `served-assets/`, `immutable-assets/`: original public bytes.
- `expected-source.json`, `selected-expectations.json`: exact Git extraction and reviewed selected copy.
- `served-catalog-literals.json`, `served-presentation-literals.json`: parsed public literal proof.
- `exact-head-evidence-links.json` and copied immutable independent reports/index: future-date evidence binding.
- `catalog-lifecycle-inventory.json`: transparent total/unexpired/expired distinction.
- `prepare_expected.py`, `verify_served.py`, `capture_served.py`, `literal_parser.py`: reproducible read-only evidence tooling.
- `capture-attempts.json`: preserved helper extraction failures and bounded corrections; no product defect inferred.
- `SHA256SUMS.json`: package file manifest excluding itself and bytecode cache.

Known limits remain live provider/weather/tickets/precise physical arrival, conservative OpenNow, inherited320px Directions clipping, six web warnings/four documented skips,14 Android warnings, physical Android/WebView/GPS HOLD and signing/Play exclusion. No broad discovery or Cadaver/performance work occurred.

Brookdale naming caveat: the existing unit pairing with DELTA2-HOLLOWS refers to Haunted Hollows in Palmyra, a different attraction. The Brookdale note correctly distinguishes its separately admitted The Hollows activity and does not add a new catalog identity. This worker does not relabel that pairing as proof of a separately imported Brookdale Hollows identity.
