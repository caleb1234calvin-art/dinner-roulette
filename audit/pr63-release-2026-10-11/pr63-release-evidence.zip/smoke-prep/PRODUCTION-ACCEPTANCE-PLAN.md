# PR63 scoped acceptance preparation

Exact candidate f92870632b71def18d7642596dc9dd3357675f76 / tree9153ead1946bbbb7e38c45981c47332997001c3e. Preparation is read-only; no browser ran and no product/repository files changed.

## Served-source proof, ready after deployment

`prepare_expected.py` has extracted exact Git objects into `expected-source.json` and `selected-expectations.json`. It asserts all59 old catalogs byte-equal base, 60 unique identities, and all60 presentations: Goblin new, Brookdale/Hotel only amendments, other57 prior presentations unchanged.

Capture the current public HTML and its script/modulepreload assets after authenticated deployment/source/alias acceptance. Keep URL/status/headers/hash receipts, original HTML and unmodified JS under a dedicated directory. Do not execute fetched JavaScript in the binding parser. Then:

```sh
python /workspace/scratch/f3247fc3b2b9/smoke-prep/verify_served.py --assets-dir /workspace/scratch/f3247fc3b2b9/smoke-prep/served-assets --deployment DEPLOYMENT_ID --origin https://pickforus.app/
```

This writes `production-source-binding.json`, all60 parsed catalog literals and full60 presentation map with comparison proof, SHA256s, selected-record details, unchanged Werehouse legacy availability, singular canonical IDs. It fails on omitted/duplicate/divergent objects. Supply the actual deployment ID, never a predicted one. The parser's extraction method was checked against the preserved PR62 public assets and found its59 catalogs. The PR63 served verifier itself remains unexecuted until actual new assets exist.

Do not describe a successful data parse as full live runtime or future-clock acceptance. Bind it to retained exact-head Web38107379751, Android38107379726, 87 selected browser scenarios, full1178 browser scenarios, 498 geometry comparisons/15 negative controls, and exact source fingerprint f5e2385ea77bead33b8fec64c3d7dbc939718e34eeedf12acb0722a1a7c11bba. Controlling report/manifests are in audit/pr63-final-validation-2026-10-11/ at authoritative continuity8c2bde9d9df332268ae5bd1a5ce85bb7ea72314a.

## Live current-time UI scope

Use normal Date Night controls. Keep Open Now off, Spooky Season on, and a bounded regional location/radius for each of three regions. Inspect actual UI/card/Details pixels plus link destination attributes; do not follow Maps, rideshare, telephone, ticket or venue links. Record warnings honestly. No broad provider discovery or performance benchmarking.

1. **Hartville** — locate The Goblin King's Haunted Trail — Shadow's Play. Its qualified point is37.2632207,-92.6693091. Verify exactly one visible identity; Haunted House classification, Limited completeness, one compact notice, approximate-distance language, artwork, collapsed/expanded Details and actual supported address. Full-result Directions destination must decode to `5651 State Hwy F, Hartville, MO 65667`; Uber is generic https://m.uber.com/ with external destination selection. Details: October2–3,9–10,16–17,23–24,2026; selected-event hours only; outdoor uneven woods/darkness/fog/loud sounds/sudden scares; closed-toe shoes/weather clothing; weather/site closure; approximate location. No Feast October31 inference. The source-bound cutoff is2026-10-25T05:00:00Z, not a final closing-time claim.
2. **Eureka/Brookdale** — Brookdale Farms Fall Festival; point38.465355,-90.616517. Keep Corn Maze/Pumpkin Patch or Anything eligible. Directions `8004 Twin Rivers Road, Eureka, MO 63025`. Expanded Details must retain September11–November8,2026, date-specific calendar, activity/weather/staffing qualifiers, dog waiver, plus exact new sentence: “The Hollows haunted trail uses separate admission and its own October calendar.” Source-bound final cutoff remains November8 18:00CST (2026-11-09T00:00:00Z). Do not count this copy amendment as an added catalog identity.
3. **Springfield** — Hotel of Terror and Dungeons of Doom must remain separately visible and separately navigable. Hotel Directions `334 N Main Avenue, Springfield, MO 65806`; Dungeons Directions `701 W Wall Street, Springfield, MO 65802`. Hotel Details retain selected September11–October31, doors7p.m., variable attendance-driven closing, fingerprint liability waiver, sensory/wet conditions, and add “A combo pass with Dungeons of Doom includes transfer rides between the two haunts.” Dungeons details are unchanged. No invented specific vehicle/inventory/dropoff promise.
4. **Saved/reload** — save a representative selected result via normal Save action, visit Favorites, reload, verify one saved entry with current title/address/Approx./Directions and no stale24/7 or precise coordinate route. Remove the disposable saved item normally after recording. Existing favorites are not to be cleared.
5. **Open Now / local filtering** — toggle Open Now on in a selected region and confirm these never-machine-OpenNow records leave active picks; toggle off restores. Record current result state; do not require all provider rows to disappear. Check category/Anything switching and absence of duplicate selected identities.
6. **Ordinary Date Night** — select an ordinary category such as Parks, confirm ordinary cards/pick/options behave, ordinary hours warnings remain ordinary, and selected haunt-only rows are excluded. At least one ordinary pick plus normal close/navigation/reload exercises the unchanged flow. No live provider completeness guarantee follows.

## Identity nuance

The existing `seasonal-next-missouri.test.mjs` pair MO26-085/DELTA2-HOLLOWS compares Brookdale to **Haunted Hollows Haunted Trail in Palmyra**, not to a separately imported Brookdale The Hollows record. Preserve and report the source data exactly. Brookdale's amendment distinguishes its separately admitted activity; no additional Brookdale Hollows catalog identity is created by PR63. Do not conflate these two different Hollows attractions when describing acceptance.

## Future-date and fixture coverage

The existing `scripts/seasonal-ten-record-browser.mjs` is NOT safely repointable to production: origin is hardcoded127.0.0.1:8099, it starts its own Vite preview with a preload that controls server provider responses/date, injects a browser Date clock/localStorage, and asserts local build proof. It is deliberately local and server-bound. Do not rewrite it during an immutable release or claim browser-only interception controls production server provider calls.

The already-passed exact-head command is:

```sh
CI=true VITE_AUTH_ENABLED=true SEASONAL_NEXT_MISSOURI=true node scripts/seasonal-ten-record-browser.mjs
```

Its prerequisites are the same exact source/dependencies, captured/completed browser build proof and auth-enabled direct Vite build; it is not an instruction to rerun it now. Existing results cover selected87 scenarios including full result/options/plans, duplicate/provider24/7 orders, cache/season/local filtering, saved/alias/current-policy reload, exact cutoff resume on all three overlays, pending RPC crossing cutoff and2027. Source references: browser lines703–739 resume/cache/no2027,820–848 saved/reload,893–920 pending RPC; unit lines80–140 per-row cutoff -1ms/exact/+1ms/cache/negative/saved/server fallback and2027. The source-bound served-data comparison plus verified deployed SHA/tree/build route retains those future-date claims without changing live clock.

Known limitations remain inherited320px Directions clipping, six web warnings/four inherited skips,14 Android warnings, fixture-provider limits, qualified approximate placement, conservative OpenNow, no ticket/weather guarantee, physical Android/WebView/GPS HOLD and signing/Play out of scope. The supplementary cumulative text-log export limitation does not replace or invalidate preserved complete raw proof.
