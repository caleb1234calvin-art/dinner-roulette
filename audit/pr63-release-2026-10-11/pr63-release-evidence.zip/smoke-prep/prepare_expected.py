"""Read exact Git objects and write reviewable PR63 expectations; no repo mutation."""
import copy, hashlib, json, pathlib, re, subprocess
from literal_parser import parse

OUT = pathlib.Path(__file__).parent
REPO = pathlib.Path('/workspace/scratch/b32d3f8a7b78/release-repo')
HEAD = 'f92870632b71def18d7642596dc9dd3357675f76'
TREE = '9153ead1946bbbb7e38c45981c47332997001c3e'
BASE = 'bf88443932739a9448fac8d27fd845e9947cf697'
def get(path, ref=HEAD): return subprocess.check_output(['git','show',f'{ref}:{path}'],cwd=REPO)
def sha(data): return hashlib.sha256(data).hexdigest()
def write(name, value): (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

assert subprocess.check_output(['git','rev-parse',f'{HEAD}^{{tree}}'],cwd=REPO,text=True).strip()==TREE
baseline=json.loads(get('scripts/test-support/next-missouri-baseline-receipts.json'))
projections=json.loads(get('scripts/test-support/next-missouri-browser-projections.json'))
assert baseline['ref']==BASE
assert sha(get('scripts/test-support/next-missouri-browser-projections.json'))=='0b406b9131d2e3149c05366d68a97d34ee2897b77542762e5f5829c259d2e2c5'
paths=list(baseline['files'])+['src/lib/date-night/missouri-2026-next-catalog.ts']
rows=[]; files=[]
for path in paths:
    raw=get(path); text=raw.decode()
    array,_=parse(text,re.search(r'=\s*\[',text).end()-1)
    if path in baseline['files']:
        assert sha(raw)==baseline['files'][path],path
        assert raw==get(path,BASE),path
    rows.extend(array)
    files.append({'path':path,'sha256':sha(raw),'count':len(array),'prior59Unchanged':path in baseline['files']})
assert len(rows)==len({r['id'] for r in rows})==60
text=get('src/lib/date-night/seasonal-presentation-catalog.ts').decode()
presentations,_=parse(text,re.search(r'SEASONAL_PRESENTATIONS:[\s\S]*?=\s*\{',text).end()-1)
assert len(presentations)==60
amended={item['recordId']:item for item in projections['amendments']}
for recordId, old in baseline['presentations'].items():
    if recordId in amended:
        expected=copy.deepcopy(old); expected['details']=amended[recordId]['after']
        assert presentations[recordId]==expected,recordId
    else: assert presentations[recordId]==old,recordId
goblin=rows[-1]; p=projections['newRecords'][0]
assert goblin['id']==p['canonicalId']
assert goblin['seasonalAvailability']['activeDates']==p['exactActiveDates']
assert goblin['seasonalListing']['listingExpiresAt']==p['listingExpiresAt']
assert presentations[p['recordId']]=={'canonicalId':p['canonicalId'],'confidence':'limited','details':p['details']}
availability=get('src/lib/date-night/availability.ts').decode()
legacy,_=parse(availability,re.search(r'SEASONAL_VENUE_AVAILABILITY:[\s\S]*?=\s*\{',availability).end()-1)
selectedIds=[p['canonicalId']]+[a['canonicalId'] for a in projections['amendments']]
counterpartIds=['date-night-mo26-125-dungeons-of-doom']
selected=[r for r in rows if r['id'] in selectedIds+counterpartIds]
write('expected-source.json',{'source':HEAD,'tree':TREE,'base':BASE,'catalogCount':60,'catalogFiles':files,'records':rows,'presentations':presentations,'legacyAvailability':legacy,'selectedIds':selectedIds,'counterpartIds':counterpartIds,'catalogProof':'All59 prior raw catalog objects unchanged; Goblin sole new object. Two presentation-only amendments; other57 prior presentations unchanged.'})
write('selected-expectations.json',{'source':HEAD,'records':selected,'presentations':{r['seasonalListing']['recordId']:presentations[r['seasonalListing']['recordId']] for r in selected},'goblinProjection':p})
print(json.dumps({'verdict':'PREPARATION_PASS','source':HEAD,'tree':TREE,'count':len(rows),'presentations':len(presentations),'selected':[{'name':r['name'],'address':r['address'],'placement':r['seasonalListing']['placement'],'cutoff':r['seasonalListing']['listingExpiresAt']} for r in selected],'expectedSha256':sha((OUT/'expected-source.json').read_bytes())},ensure_ascii=False,indent=2))
