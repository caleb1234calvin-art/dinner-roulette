"""Read-only data binding against locally captured public production assets.

Usage: python verify_served.py --assets-dir DIR --deployment dpl_... --origin https://pickforus.app/
The caller must separately verify deployment ID/source and downloaded URL/status.
This never fetches or executes JavaScript and never changes the repo or product.
"""
import argparse,collections,datetime,hashlib,json,pathlib,re
from literal_parser import parse

parser=argparse.ArgumentParser()
parser.add_argument('--assets-dir',required=True)
parser.add_argument('--deployment',required=True)
parser.add_argument('--origin',default='https://pickforus.app/')
args=parser.parse_args()
OUT=pathlib.Path(__file__).parent
assets=pathlib.Path(args.assets_dir)
expected=json.loads((OUT/'expected-source.json').read_text())
sha=lambda data:hashlib.sha256(data).hexdigest()
rowOccurrences=[]; presentationOccurrences=[]; legacyOccurrences=[]; files=[]
capture=json.loads((OUT/'served-assets-download.json').read_text())
assert capture['deployment']==args.deployment and capture['source']==expected['source']
applicationNames={pathlib.Path(item['path']).name for item in capture['assets'] if item['originName']=='production' and item['entryPath'].startswith('/assets/')}
for path in sorted(p for p in assets.glob('*.js') if p.name in applicationNames):
    raw=path.read_bytes(); text=raw.decode()
    files.append({'name':path.name,'bytes':len(raw),'sha256':sha(raw)})
    for match in re.finditer(r'\{\s*(?:id|"id"|\x27id\x27)\s*:',text):
        try: row,end=parse(text,match.start())
        except (ValueError,IndexError,SyntaxError): continue
        if row.get('seasonalListing',{}).get('contract')=='ListingCompletenessV1':
            rowOccurrences.append({'file':path.name,'offset':match.start(),'record':row})
    for match in re.finditer(r'\{\s*["\x27]DELTA3-GOBLIN["\x27]\s*:',text):
        try: obj,end=parse(text,match.start())
        except (ValueError,IndexError,SyntaxError): continue
        if isinstance(obj.get('DELTA3-GOBLIN'),dict) and 'canonicalId' in obj['DELTA3-GOBLIN']:
            presentationOccurrences.append({'file':path.name,'offset':match.start(),'value':obj})
    for match in re.finditer(r'\{\s*["\x27]date-night-werehouse-joplin["\x27]\s*:',text):
        try: obj,end=parse(text,match.start())
        except (ValueError,IndexError,SyntaxError): continue
        if isinstance(obj.get('date-night-werehouse-joplin'),dict) and 'openNowPolicy' in obj['date-night-werehouse-joplin']:
            legacyOccurrences.append({'file':path.name,'offset':match.start(),'value':obj})
assert len(rowOccurrences)==60,('Expected exactly60 catalog literals in captured direct assets',len(rowOccurrences))
counts=collections.Counter(item['record']['id'] for item in rowOccurrences)
assert all(v==1 for v in counts.values()),('Duplicate literal identity',counts)
byId={item['record']['id']:item['record'] for item in rowOccurrences}
assert set(byId)=={r['id'] for r in expected['records']},'Catalog identity set divergence'
for row in expected['records']: assert byId[row['id']]==row,('Catalog field divergence',row['id'])
assert len(presentationOccurrences)==1,('Presentation map occurrence count',len(presentationOccurrences))
assert presentationOccurrences[0]['value']==expected['presentations'],'Consumer presentation divergence'
assert len(legacyOccurrences)==1,('Legacy availability map occurrence count',len(legacyOccurrences))
assert legacyOccurrences[0]['value']==expected['legacyAvailability'],'Legacy availability divergence'
selected=[]
for id in expected['selectedIds']+expected['counterpartIds']:
    row=byId[id];listing=row['seasonalListing'];availability=row['seasonalAvailability']
    selected.append({'id':id,'name':row['name'],'address':row['address'],'directionsTarget':listing['directionsTarget'],'placement':listing['placement'],'listingExpiresAt':listing['listingExpiresAt'],'expiryBasis':listing['expiryBasis'],'seasonYear':listing['seasonYear'],'activeDates':availability.get('activeDates'),'openingHours':row.get('openingHours'),'openNowPolicy':availability.get('openNowPolicy'),'presentation':expected['presentations'][listing['recordId']]})
receipt={'verdict':'PASS','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'deployment':args.deployment,'deploymentIdentityBasis':'Caller-supplied ID; release operator must separately bind metadata/source/aliases','source':expected['source'],'tree':expected['tree'],'origin':args.origin,'method':'Parse captured public production application data literals without executing downloaded JavaScript; complete recursive equality to exact Git object extraction. External extension script was not fetched; captured Vercel telemetry is excluded from application-literal parsing and kept in original transport bytes.','catalogCount':60,'prior59Unchanged':True,'goblinOnlyNewIdentity':True,'presentationCount':60,'twoAmendmentsEqual':True,'other57PriorPresentationsUnchanged':True,'legacyAvailabilityEqual':True,'noDuplicateCatalogIdentities':True,'selected':selected,'files':files,'expectedSourceSha256':sha((OUT/'expected-source.json').read_bytes()),'captureReceiptSha256':sha((OUT/'served-assets-download.json').read_bytes()),'qualifications':['Requires separate authenticated deployment/source/aliases verification and URL/status capture receipts.','Source/data binding is not a production future-clock experiment. Retained exact-head expiry/cache/pendingRPC/no2027 behavior evidence remains separately linked.','No byte-for-byte whole CI/Vercel output equality claim.','No live provider/ticket/weather or precise physical entrance guarantee.']}
(OUT/'production-source-binding.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
(OUT/'served-catalog-literals.json').write_text(json.dumps(rowOccurrences,ensure_ascii=False,indent=2)+'\n')
(OUT/'served-presentation-literals.json').write_text(json.dumps(presentationOccurrences,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'verdict':'PASS','catalogs':60,'presentations':60,'deployment':args.deployment,'receipt':str(OUT/'production-source-binding.json'),'receiptSha256':sha((OUT/'production-source-binding.json').read_bytes())},indent=2))
