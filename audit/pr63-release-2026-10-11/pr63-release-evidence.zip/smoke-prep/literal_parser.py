"""Read JavaScript data literals without executing JavaScript."""
import re,json,ast

class LiteralParser:
    def __init__(self,text,pos=0): self.s=text; self.i=pos
    def skip(self):
        while True:
            m=re.match(r'\s+|//[^\n]*(?:\n|$)|/\*[\s\S]*?\*/',self.s[self.i:])
            if not m: return
            self.i+=m.end()
    def string(self):
        start=self.i; quote=self.s[self.i];self.i+=1
        while self.i<len(self.s):
            c=self.s[self.i];self.i+=1
            if c=='\\':self.i+=1
            elif c==quote:
                raw=self.s[start:self.i]
                if quote=='`':
                    body=raw[1:-1]
                    if re.search(r'(?<!\\)\$\{',body):raise ValueError('Refusing interpolated template')
                    def escape(m):
                        x=m.group()[1:]
                        if x.startswith('u{'):return chr(int(x[2:-1],16))
                        if x.startswith('u'):return chr(int(x[1:],16))
                        if x.startswith('x'):return chr(int(x[1:],16))
                        return {'n':'\n','r':'\r','t':'\t','b':'\b','f':'\f','v':'\v','0':'\0','\n':'','\r\n':''}.get(x,x)
                    return re.sub(r'\\(?:u\{[0-9a-fA-F]+\}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{2}|\r\n|[\s\S])',escape,body)
                try:return json.loads(raw)
                except Exception:return ast.literal_eval(raw.replace('\\/','/'))
        raise ValueError('Unterminated string')
    def value(self):
        self.skip();c=self.s[self.i]
        if c in '\"\x27`':
            value=self.string();self.skip()
            # The minifier encodes repeated string arrays as a constant split.
            # Interpret that single data encoding; never eval or execute JS.
            if self.s.startswith('.split(',self.i):
                self.i+=7;self.skip()
                if self.s[self.i] not in '\"\x27`':raise ValueError('Nonliteral split delimiter')
                delimiter=self.string();self.skip()
                if not delimiter or self.s[self.i]!=')':raise ValueError('Unsupported split expression')
                self.i+=1;return value.split(delimiter)
            return value
        if c=='{':
            self.i+=1;out={};self.skip()
            while self.s[self.i]!='}':
                if self.s[self.i] in '\"\x27':key=self.string()
                else:
                    m=re.match(r'[A-Za-z_$][A-Za-z0-9_$]*|\d+',self.s[self.i:])
                    if not m:raise ValueError('Nonliteral key near '+self.s[self.i:self.i+70])
                    key=m.group();self.i+=m.end()
                self.skip()
                if self.s[self.i]!=':':raise ValueError('Nonliteral property near '+self.s[self.i:self.i+70])
                self.i+=1;val=self.value()
                if key in out:raise ValueError('Duplicate literal key '+key)
                out[key]=val;self.skip()
                if self.s[self.i]==',':self.i+=1;self.skip()
                elif self.s[self.i]!='}':raise ValueError('Nonliteral expression near '+self.s[self.i:self.i+70])
            self.i+=1;return out
        if c=='[':
            self.i+=1;out=[];self.skip()
            while self.s[self.i]!=']':
                out.append(self.value());self.skip()
                if self.s[self.i]==',':self.i+=1;self.skip()
                elif self.s[self.i]!=']':raise ValueError('Nonliteral array near '+self.s[self.i:self.i+70])
            self.i+=1;return out
        m=re.match(r'(![01]|true\b|false\b|null\b)',self.s[self.i:])
        if m:self.i+=m.end();return {'!0':True,'!1':False,'true':True,'false':False,'null':None}[m.group()]
        m=re.match(r'-?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?',self.s[self.i:])
        if m:
            self.i+=m.end();x=m.group();return float(x) if any(c in x for c in '.eE') else int(x)
        raise ValueError('Refusing nonliteral expression near '+self.s[self.i:self.i+100])

def parse(text,pos=0):
    p=LiteralParser(text,pos);value=p.value();return value,p.i
