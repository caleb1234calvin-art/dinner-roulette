"""Bounded public GET capture of two origins and their same-origin entry JS assets."""
import concurrent.futures,datetime,hashlib,json,pathlib,urllib.request,urllib.parse
from html.parser import HTMLParser
OUT=pathlib.Path(__file__).parent
ASSETS=OUT/'served-assets'; ASSETS.mkdir(exist_ok=True)
origins={'production':'https://pickforus.app/','immutable':'https://dinner-roulette-a3n6j3i8n-minions-9e2c.vercel.app/'}
def get(url):
    req=urllib.request.Request(url,headers={'User-Agent':'PickForUs-ReleaseAcceptance/63','Cache-Control':'no-cache'})
    with urllib.request.urlopen(req,timeout=30) as r:
        data=r.read(8*1024*1024+1)
        assert len(data)<=8*1024*1024,('Bounded capture exceeded',url)
        return data,{'requestedUrl':url,'finalUrl':r.url,'status':r.status,'headers':dict(r.headers),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
class Entries(HTMLParser):
    def __init__(self):super().__init__();self.paths=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs); value=a.get('src') if tag=='script' else a.get('href') if tag=='link' and a.get('rel')=='modulepreload' else None
        if value and urllib.parse.urlparse(value).path.endswith('.js'):self.paths.append(value)
pages={}; urls={}
for name,origin in origins.items():
    raw,receipt=get(origin);(OUT/f'{name}-index.html').write_bytes(raw)
    parser=Entries();parser.feed(raw.decode()); discovered=sorted(set(parser.paths));assert 1<=len(discovered)<=20,discovered
    paths=[]; excluded=[]
    for path in discovered:
        url=urllib.parse.urljoin(origin,path)
        if urllib.parse.urlparse(url).netloc!=urllib.parse.urlparse(origin).netloc:
            excluded.append(url);continue
        paths.append(path)
        urls[(name,path)]=url
    receipt['entryPaths']=paths;receipt['externalScriptsNotFetched']=excluded;pages[name]=receipt
assert pages['production']['entryPaths']==pages['immutable']['entryPaths'],'Entry assets differ between apex and immutable deployment'
captures=[]
def capture(item):
    (name,path),url=item;raw,receipt=get(url)
    target=ASSETS/pathlib.Path(urllib.parse.urlparse(path).path).name if name=='production' else OUT/'immutable-assets'/pathlib.Path(urllib.parse.urlparse(path).path).name
    target.parent.mkdir(exist_ok=True);target.write_bytes(raw)
    receipt.update({'originName':name,'entryPath':path,'path':str(target)})
    return receipt
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:captures=list(pool.map(capture,urls.items()))
byEntry={(r['originName'],r['entryPath']):r for r in captures}
for path in pages['production']['entryPaths']:
    assert byEntry[('production',path)]['sha256']==byEntry[('immutable',path)]['sha256'],('Served JS differs between apex/immutable',path)
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'deployment':'dpl_7MmWVLGr9roCmWit3yzASutdRZGs','source':'f92870632b71def18d7642596dc9dd3357675f76','identityBasis':'Root operator authenticated deployment/source readback; this script independently reads public outputs','verdict':'PASS','entryAssetEquality':True,'pages':pages,'assets':captures,'requestCount':len(captures)+len(pages),'method':'Bounded public HTML plus directly referenced same-origin entry JS GETs only. No JavaScript execution or provider requests.'}
(OUT/'served-assets-download.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'verdict':'PASS','requests':receipt['requestCount'],'entryAssets':pages['production']['entryPaths'],'allEntryBytesEqual':True},indent=2))
