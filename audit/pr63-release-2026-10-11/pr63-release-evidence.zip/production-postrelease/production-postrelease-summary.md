# PR 63 postrelease deployment and alias acceptance

Independent read-only checks completed 2026-10-11 22:30 UTC. PASS.

- Current deployment dpl_7MmWVLGr9roCmWit3yzASutdRZGs READY, production target, exact source f92870632b71def18d7642596dc9dd3357675f76, immutable hostname dinner-roulette-a3n6j3i8n-minions-9e2c.vercel.app.
- Five of five independently fetched alias mappings point to this deployment.
- Five of five public HTTP requests returned final 200 and HTML title Pick For Us. www.pickforus.app redirected 308 to https://pickforus.app/ before 200. All five reference the new common application asset /assets/index-Bp9wA5ps.js.
- Two of two retained deployment checks pass: dpl_HaYiRu6aYS9ubAPWdJGhh41jtV8U READY/source bf88443932739a9448fac8d27fd845e9947cf697; dpl_8xyE9R3BxyE1883QpavaEBWV2LGa READY/source fe22c15cc6442fc4a48fec23c9a1331c69d70bd2.
- Deployment response alias arrays can retain historical names; current routing is established by the five independent get-alias responses, not those historical deployment arrays.
- No remote mutations, provider traffic, source changes, or browser use.

Evidence: vercel-identity-aliases.json; http-health.json; individual host .headers and .html files.
