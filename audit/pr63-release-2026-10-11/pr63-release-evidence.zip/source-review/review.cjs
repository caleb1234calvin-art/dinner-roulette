const {execFileSync}=require('node:child_process');
const {stripTypeScriptTypes}=require('node:module');
const path=require('node:path');
const fs=require('node:fs');
const assert=require('node:assert/strict');
const {createHash}=require('node:crypto');
const repo='/workspace/scratch/b32d3f8a7b78/release-repo';
const head='f92870632b71def18d7642596dc9dd3357675f76';
const base='bf88443932739a9448fac8d27fd845e9947cf697';
const git=(...args)=>execFileSync('git',args,{cwd:repo,encoding:'utf8',maxBuffer:10*1024*1024});
const sha=s=>createHash('sha256').update(s).digest('hex');
const loader=ref=>{
 const mods=new Map();
 const files=new Set(git('ls-tree','-r','--name-only',ref).trim().split('\n'));
 function load(file){
  if(mods.has(file))return mods.get(file);
  const exports={};mods.set(file,exports);
  let source=stripTypeScriptTypes(git('show',ref+':'+file),{mode:'transform',sourceMap:false});
  const names=[];
  source=source.replace(/import\s+\{([\s\S]*?)\}\s+from\s+["']([^"']+)["'];?/g,(_,bindings,spec)=>`const {${bindings.replace(/\bas\b/g,':')}} = load(${JSON.stringify(spec)});`);
  source=source.replace(/export\s+(const|let|var|function|class)\s+(\w+)/g,(_,kind,name)=>{names.push(name);return `${kind} ${name}`});
  const child=spec=>{if(!spec.startsWith('.')&&!spec.startsWith('@/')) return require(spec);const root=spec.startsWith('@/')?'src/'+spec.slice(2):path.posix.normalize(path.posix.join(path.posix.dirname(file),spec));const found=[root,root+'.ts',root+'.js',root+'.mjs'].find(p=>files.has(p));assert.ok(found,`resolve ${spec} in ${file}`);return load(found);};
  new Function('load','exports',source+'\nObject.assign(exports,{'+names.join(',')+'});')(child,exports);
  return exports;
 }
 return load;
};
const load=loader(head),before=loader(base);
const commit=git('cat-file','-p',head);assert.match(commit,/^tree 9153ead1946bbbb7e38c45981c47332997001c3e\nparent ca1a2979fa3c07fe2ed4f417e153f152288d1553\n/);
assert.equal(git('rev-list','--count',base+'..'+head).trim(),'2');
const diffNames=git('diff','--name-only',base,head).trim().split('\n');
const runtime=diffNames.filter(p=>p.startsWith('src/'));
assert.deepEqual(runtime,['src/lib/date-night/curated-policy.ts','src/lib/date-night/missouri-2026-next-catalog.ts','src/lib/date-night/search.ts','src/lib/date-night/seasonal-presentation-catalog.ts']);
const priorPaths=git('ls-tree','-r','--name-only',base,'src/lib/date-night').trim().split('\n').filter(p=>/\/missouri-.*catalog\.ts$/.test(p));
const rows=[];
for(const p of priorPaths){assert.equal(git('show',base+':'+p),git('show',head+':'+p),p);for(const [key,value]of Object.entries(load(p)))if(key.endsWith('_CATALOG'))rows.push(...value);}
assert.equal(rows.length,59);assert.equal(new Set(rows.map(r=>r.id)).size,59);
const additions=load('src/lib/date-night/missouri-2026-next-catalog.ts').MISSOURI_2026_NEXT_CATALOG;
assert.equal(additions.length,1);const all=[...rows,...additions];assert.equal(new Set(all.map(r=>r.id)).size,60);
const oldPresentations=before('src/lib/date-night/seasonal-presentation-catalog.ts').SEASONAL_PRESENTATIONS;
const presentations=load('src/lib/date-night/seasonal-presentation-catalog.ts').SEASONAL_PRESENTATIONS;
assert.equal(Object.keys(presentations).length,60);
const amended={'MO26-085':'The Hollows haunted trail uses separate admission and its own October calendar.','MO26-124':'A combo pass with Dungeons of Doom includes transfer rides between the two haunts.'};
for(const [id,p]of Object.entries(oldPresentations)){if(amended[id])assert.deepEqual(presentations[id],{...p,details:[...p.details.slice(0,-1),amended[id],p.details.at(-1)]});else assert.deepEqual(presentations[id],p,id);}
const byId=Object.fromEntries(all.map(r=>[r.seasonalListing.recordId,r]));
const goblin=additions[0];assert.equal(goblin.seasonalListing.recordId,'DELTA3-GOBLIN');assert.equal(goblin.address,'5651 State Hwy F, Hartville, MO 65667');
assert.deepEqual(goblin.seasonalAvailability.activeDates,['2026-10-02','2026-10-03','2026-10-09','2026-10-10','2026-10-16','2026-10-17','2026-10-23','2026-10-24']);
assert.equal(Date.parse(goblin.seasonalListing.listingExpiresAt),Date.parse('2026-10-25T05:00:00Z'));
assert.equal(goblin.seasonalListing.expiryBasis,'date-only');assert.equal(goblin.seasonalListing.placement.basis,'operator-site');
assert.deepEqual([goblin.lat,goblin.lon],[37.2632207,-92.6693091]);assert.equal(goblin.openingHours,null);assert.equal(goblin.seasonalAvailability.openNowPolicy,'never');
assert.equal(goblin.seasonalListing.hours.state,'partial');assert.equal(goblin.seasonalAvailability.endsAt,undefined);
const selected=['DELTA3-GOBLIN','MO26-085','MO26-124'].map(id=>byId[id]);
const now=new Date();for(const r of selected){assert.ok(Date.parse(r.seasonalListing.listingExpiresAt)>+now);assert.equal(r.seasonalListing.seasonYear,2026);assert.equal(r.seasonalListing.contract,'ListingCompletenessV1');}
assert.equal(Date.parse(byId['MO26-085'].seasonalListing.listingExpiresAt),Date.parse('2026-11-08T18:00:00-06:00'));
assert.notEqual(byId['MO26-124'].address,byId['MO26-125'].address);assert.notEqual(byId['MO26-085'].id,byId['DELTA2-HOLLOWS'].id);
const baseline=JSON.parse(git('show',head+':scripts/test-support/next-missouri-baseline-receipts.json'));assert.deepEqual(baseline.presentations,oldPresentations);
for(const [p,h]of Object.entries(baseline.files)){assert.equal(sha(git('show',base+':'+p)),h,p);assert.equal(sha(git('show',head+':'+p)),h,p);}
const pkg=JSON.parse(git('show',head+':package.json'));assert.match(pkg.scripts.build,/npm run db:migrate/);
const workflow=git('show',head+':.github/workflows/validate-icon-pack.yml');assert.match(workflow,/node scripts\/with-app-env\.mjs node node_modules\/vite\/bin\/vite\.js build --mode production/);assert.match(workflow,/VITE_AUTH_ENABLED: "true"/);
const report={status:'PASS',at:now.toISOString(),continuityRead:{path:'/workspace/scratch/f3247fc3b2b9/continuity-authoritative.md',lines:'106-1200',complete:true},candidate:{sha:head,tree:'9153ead1946bbbb7e38c45981c47332997001c3e',parent:'ca1a2979fa3c07fe2ed4f417e153f152288d1553',base,commitsAhead:2},changedPaths:diffNames,runtimePaths:runtime,catalogCount:all.length,uniqueIdentities:new Set(all.map(r=>r.id)).size,priorCatalogFilesUnchanged:priorPaths.length,priorCatalogObjectsUnchanged:rows.length,unchangedPriorPresentations:57,amendedPresentations:amended,selected:selected.map(r=>({id:r.id,recordId:r.seasonalListing.recordId,address:r.address,expiry:r.seasonalListing.listingExpiresAt,expiryUtc:new Date(r.seasonalListing.listingExpiresAt).toISOString(),openingHours:r.openingHours,openNowPolicy:r.seasonalAvailability.openNowPolicy})),counterparts:['DELTA2-HOLLOWS','MO26-125'].map(id=>({id:byId[id].id,address:byId[id].address,expiry:byId[id].seasonalListing.listingExpiresAt})),excludedRuntime:/cadaver/i.test(JSON.stringify(all))?'FOUND':'absent',safeBuildSource:'VITE_AUTH_ENABLED=true node scripts/with-app-env.mjs node node_modules/vite/bin/vite.js build --mode production',hostedEffectiveBuildSettings:'Requires fresh authenticated setting readback by release coordinator',scopeReview:'Only one catalog addition + two presentation notes and catalog registration runtime changes. Harness adds selected scenarios and exact-object controls; CI splits every existing suite into independent matrix runners with fail-closed aggregate validate gate.',limitations:['Object-source review, not new full-suite execution','Prior hosted exact-head validation remains separately authoritative','Live ticket inventory/weather/provider and physical Android are not proven']};
fs.writeFileSync('/workspace/scratch/f3247fc3b2b9/source-review/source-preflight.json',JSON.stringify(report,null,2)+'\n');
fs.writeFileSync('/workspace/scratch/f3247fc3b2b9/source-review/complete-candidate-catalog.json',JSON.stringify(all,null,2)+'\n');
fs.writeFileSync('/workspace/scratch/f3247fc3b2b9/source-review/complete-candidate-presentations.json',JSON.stringify(presentations,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
