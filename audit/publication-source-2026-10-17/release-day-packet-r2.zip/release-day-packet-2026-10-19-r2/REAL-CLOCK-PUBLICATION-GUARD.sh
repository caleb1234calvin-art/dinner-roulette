#!/usr/bin/env bash
# Read-only release-day check. This script neither releases nor grants authority.
set -euo pipefail
if [[ $# -ne 3 ]]; then
  printf '%s\n' 'Usage: bash REAL-CLOCK-PUBLICATION-GUARD.sh /absolute/repo EXACT_HEAD EXACT_TREE' >&2
  exit 64
fi
script_dir=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
repo=$1
expected_head=$2
expected_tree=$3
[[ "$repo" = /* ]] || { echo 'HOLD: repository path must be absolute' >&2; exit 64; }
[[ "$expected_head" =~ ^[0-9a-f]{40}$ && "$expected_tree" =~ ^[0-9a-f]{40}$ ]] || {
  echo 'HOLD: exact reviewed full head and tree SHA values are required' >&2; exit 64;
}
cd -- "$repo"
[[ "$(pwd -P)" = "$(git rev-parse --show-toplevel)" ]] || { echo 'HOLD: run at the repository root' >&2; exit 1; }
[[ "$(git rev-parse HEAD)" = "$expected_head" ]] || { echo 'HOLD: HEAD differs from the exact reviewed source' >&2; exit 1; }
[[ "$(git rev-parse 'HEAD^{tree}')" = "$expected_tree" ]] || { echo 'HOLD: tree differs from the exact reviewed source' >&2; exit 1; }
if ! tracked_flags=$(git ls-files -v); then
  echo 'HOLD: unable to inspect tracked-file flags' >&2; exit 1
fi
if grep -E '^([a-z]|S) ' <<< "$tracked_flags" > /dev/null; then
  echo 'HOLD: assume-unchanged/skip-worktree flags are unsupported; do not treat hidden files as clean' >&2; exit 1
fi
if ! tracked_modes=$(git ls-files --stage); then
  echo 'HOLD: unable to inspect tracked-file modes' >&2; exit 1
fi
if grep -E '^160000 ' <<< "$tracked_modes" > /dev/null; then
  echo 'HOLD: submodule source is not covered by this guard' >&2; exit 1
fi
if ! worktree_status=$(git -c core.fsmonitor=false status --porcelain --untracked-files=all); then
  echo 'HOLD: unable to inspect worktree status' >&2; exit 1
fi
[[ -z "$worktree_status" ]] || { echo 'HOLD: worktree is not clean' >&2; exit 1; }
python3 "$script_dir/VERIFY-TRACKED-SOURCE.py" "$expected_head" "$expected_tree"
node --input-type=module <<'JS'
const now = new Date();
console.log(JSON.stringify({checkedAtUtc: now.toISOString(), checkedAtChicago: new Intl.DateTimeFormat('en-US', {timeZone: 'America/Chicago', dateStyle: 'full', timeStyle: 'long'}).format(now)}, null, 2));
JS
node scripts/check-legal-release.mjs --publication --authorized-date=2026-10-19 --publication-time-zone=America/Chicago
printf '%s\n' 'DATE/SOURCE GUARD PASS ONLY. Separate exact-source owner approval, fresh main/CI/build/alias/recovery checks and attended release remain required. No action was activated.'
