#!/usr/bin/env python3
"""Compare actual tracked regular-file bytes and modes to the reviewed Git tree.

Read only. No checkout, refresh, source repair, date override or release action.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys


def hold(message):
    print('HOLD: ' + message, file=sys.stderr)
    raise SystemExit(1)


if len(sys.argv) != 3 or not all(re.fullmatch(r'[0-9a-f]{40}', s) for s in sys.argv[1:]):
    hold('exact reviewed head and tree are required')
head, expected_tree = sys.argv[1:]
try:
    tree = subprocess.check_output(['git', '--no-replace-objects', 'rev-parse', head + '^{tree}'], text=True).strip()
    if tree != expected_tree:
        hold('reviewed head does not resolve to the reviewed tree')
    raw = subprocess.check_output(['git', '--no-replace-objects', 'ls-tree', '-rz', '--full-tree', head])
except subprocess.CalledProcessError:
    hold('unable to read the exact tracked source tree')
if not raw:
    hold('empty source tree')
entries = [entry for entry in raw.split(b'\0') if entry]
attribute_paths = [entry.split(b'\t', 1)[1] for entry in entries if entry.split(b'\t', 1)[1].split(b'/')[-1] == b'.gitattributes']
normalize_crlf = False
if attribute_paths:
    if attribute_paths != [b'.gitattributes']:
        hold('unsupported nested or additional Git attributes require review')
    try:
        attributes = subprocess.check_output(['git', '--no-replace-objects', 'show', head + ':.gitattributes'])
    except subprocess.CalledProcessError:
        hold('unable to read reviewed Git attributes')
    if attributes != b'android/gradlew text eol=lf\nandroid/gradlew.bat text eol=crlf\n':
        hold('Git attributes changed; review canonicalization before checking source')
    normalize_crlf = True
count = 0
byte_count = 0
normalized_paths = []
for entry in entries:
    if not entry:
        continue
    info, raw_path = entry.split(b'\t', 1)
    mode, kind, expected_blob = info.decode('ascii').split(' ')
    path = Path(os.fsdecode(raw_path))
    if path.is_absolute() or '..' in path.parts or not path.parts:
        hold('unsupported source path: ' + repr(str(path)))
    if kind != 'blob' or mode not in ('100644', '100755'):
        hold('unsupported tracked file mode/type at ' + repr(str(path)))
    try:
        for parent in path.parents:
            if parent != Path('.') and not stat.S_ISDIR(parent.lstat().st_mode):
                hold('source parent is not a real directory: ' + repr(str(parent)))
        before = path.lstat()
        if not stat.S_ISREG(before.st_mode):
            hold('tracked source is not a regular file: ' + repr(str(path)))
        if bool(before.st_mode & 0o111) != (mode == '100755'):
            hold('tracked executable mode differs: ' + repr(str(path)))
        h = hashlib.sha1()
        read_bytes = 0
        if normalize_crlf and raw_path == b'android/gradlew.bat':
            # Only the exact committed CRLF rule above is supported. Never run
            # arbitrary configured clean filters or infer source changes away.
            data = path.read_bytes()
            read_bytes = len(data)
            canonical = data.replace(b'\r\n', b'\n')
            h.update(b'blob ' + str(len(canonical)).encode('ascii') + b'\0')
            h.update(canonical)
            if canonical != data:
                normalized_paths.append(str(path))
        else:
            h.update(b'blob ' + str(before.st_size).encode('ascii') + b'\0')
            with path.open('rb') as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b''):
                    h.update(chunk)
                    read_bytes += len(chunk)
        after = path.lstat()
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            hold('source changed during content verification: ' + repr(str(path)))
        if read_bytes != before.st_size or h.hexdigest() != expected_blob:
            hold('tracked source bytes differ from the reviewed tree: ' + repr(str(path)))
        count += 1
        byte_count += read_bytes
    except OSError as exc:
        hold('unable to inspect tracked source ' + repr(str(path)) + ': ' + str(exc))
print(json.dumps({'trackedSourceCheck': 'PASS', 'head': head, 'tree': expected_tree, 'regularFiles': count, 'bytes': byte_count, 'reviewedCrlfNormalization': normalized_paths, 'scope': 'Actual tracked bytes and executable modes, with the exact reviewed gradlew.bat EOL normalization, at this check; no atomic lock on later changes, dependencies, environment or deployment.'}, sort_keys=True))
