# R2 source binding and preserved R1 failure

Prepared October 17, 2026. This successor packet updates the exact candidate binding only. The intended October 19 / America/Chicago date, real-clock guard, release/rollback boundaries, physical NOT RUN ledger and all other operational restrictions are unchanged. No merge, deployment, recovery, signing, installation or Play action is authorized.

## Exact successor

- PR82: https://github.com/caleb1234calvin-art/dinner-roulette/pull/82
- Branch: `integration/legal-publication-source-2026-10-19`
- R2 head: `cf18ff1c5a56ecf59f8006d4f7c83fb289f393df`
- R2 tree: `6300c1061a790d84447bb92166f340aec895757b`
- Sole parent, preserved R1: `9e84b3ef5c5870774e6f7dbfbe1c2c1afa03668a`
- Only R1→R2 changes: `scripts/unified-footer-browser.mjs` and `scripts/unified-footer.test.mjs`.

The R1 hosted footer suite recorded 330 PASS / 20 FAIL. Its original result file confirms those counts and exact R1 binding. The failed cases contained stale unconditional unpublished-policy expectations. R2 replaces those test expectations with the finalized version/date/zone tuple and explicit rejection of obsolete wording, while retaining all 350 cases and existing geometry/focus/contrast/isolation controls. Application, policy text/metadata, Settings, operational validator, native inputs and deployment configuration are byte-identical to R1. The failed R1 suite is retained as FAIL; application identity does not transfer its prior browser results into R2 acceptance.

## Freshness and separate scopes

The R2 implementation receipt records a fresh migration-free auth-enabled build, 1,277 repository passes / four inherited skips, 75 application passes and 17 Python passes, plus the applicable static checks. The independent R2 source review separately repeats 91 source/API/CLI controls and 25 focused tests, plus 20 synthetic footer-assertion controls. The 20 controls are unit fixtures, not browser acceptance. These receipts are copied in `evidence/` with exact R2 identity.

Fresh hosted web run `39015345296` and Android run `39015345242` remain PENDING at this packet checkpoint. Their eventual final source-bound acceptance belongs in the final validation receipt, not a rewrite of this snapshot. Protected signing, native test NO-SOURCE and physical/live-provider limits must retain their actual reported states.

The release-day wrapper and tracked-content helper are unchanged from the independently reviewed R1 packet. A separate R2 review reruns all 19 guard regressions and the exact R2 genuine-clock command; its receipt lives in `review/`. Expected result on October 17 is HOLD. No unit-time fixture or historical wrapper output is a live October 19 PASS.

## What is preserved

The complete original folder `release-day-packet-2026-10-19/` and its 68,178-byte ZIP remain byte-identical. Original ZIP SHA256: `7f6aedd7fe0e3c8a44963ff108cad669d7beb8d0714d3254e5c52f7cc80bfd9f`. Its member hashes were verified before preparing this successor; see `evidence/R1-PRESERVATION-RECEIPT.json`.

This packet also carries the R1 guard review, source binding, release-record template and manifest as explicitly preserved references. Their then-pending hosted status describes their historical timestamp. The later R1 footer failure is documented here and in the copied original failure log; `evidence/R1-FAILURE-REFERENCE.json` identifies the full retained original artifact and its hash without duplicating its screenshots into this small packet.

All 36 phone/tablet cases remain NOT RUN, with no native installation or safe-update claim. The PR78/80/81 debug-certificate incompatibility remains in force; any later APK requires its own source/artifact/signature assessment before separately authorized installation. A new website candidate remains unpublished until the owner approves and the real release-day gates pass.
