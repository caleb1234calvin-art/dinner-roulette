# Exact commands: source validation and real-clock publication gate

These commands are operator instructions, not a scheduled action or merge/deploy script. Run only in an isolated checkout of the exact frozen publication-source candidate, or the separately approved exact integrated source. The executable guard contains no merge, deploy, settings, migration, signing, install, Play, rollback, clock-setting or source-writing command.

## Independent date conversion

October 19, 2026 in America/Chicago is UTC−05:00. The authorized calendar-day gate is the half-open interval [2026-10-19T05:00:00Z, 2026-10-20T05:00:00Z). This is an outer limit; choose a separately agreed attended time with sufficient time for build, alias transition and immediate checks. It is not permission to publish at midnight or to start a deployment that completes after the window.

Use the host's genuine current clock. Before release compare it with the operator's reliable current UTC time and record both. Do not alter system time, inject `Date`, import the validator with a synthetic `now`, set a fake-time environment, remove assertions, or treat unit-test clocks as a live publication pass. The repository CLI has no clock-override option.

## Source validation, possible before October 19

Inspect package/workflow/build route on the exact source first. The ordinary `npm run build` chains `npm run db:migrate` and MUST NOT be used. Do not change Vercel build settings to force a pass. Use installed reviewed dependencies or the already authorized clean dependency workflow; no package download/install is implied by this packet.

From the exact candidate root, after capturing head/tree, clean worktree and tool versions:

```sh
set -euo pipefail
node scripts/check-legal-release.mjs
node --test scripts/legal-release.test.mjs scripts/legal-support.test.mjs scripts/legal-storage.test.mjs scripts/check-auth-invariant.test.mjs
npm run typecheck
npm run lint
VITE_AUTH_ENABLED=true node scripts/browser-build-proof.mjs capture
VITE_AUTH_ENABLED=true node scripts/with-app-env.mjs node node_modules/vite/bin/vite.js build --mode production
VITE_AUTH_ENABLED=true node scripts/browser-build-proof.mjs complete
VITE_AUTH_ENABLED=true node scripts/browser-build-proof.mjs verify
npm test
npm run audit:casinos
npm run android:check
python3 -m unittest discover -s native-android -p 'test_*.py'
VITE_AUTH_ENABLED=true node --input-type=module -e 'import assert from "node:assert/strict"; import {buildAuthEnabled} from "./scripts/check-auth-invariant.mjs"; assert.equal(buildAuthEnabled(), true); console.log("Actual build auth resolution: ON. No live dev/build agreement asserted.");'
```

Run the production build before aggregate tests because some tests consume compiled SSR output. An early build-dependent failure is retained and followed by the complete correct rerun; do not rewrite it as a pass. `complete` is run only after successful build due to `set -e`. Build proof verifies its actual selected source inputs and `.vercel/output`; it does not cover every repository file, live production or release authorization. Record full Git tree as well.

Run exact-source hosted CI and applicable independent legal/footer browser acceptance. Preserve run IDs, tested head and merge SHA where present, job/step results and original artifact hashes. Expected signing skips or native NO-SOURCE tasks remain explicitly such. A workflow run green on a predecessor, an unrelated merge SHA or a different source fingerprint is not final-source validation. Preserve independent rendered Privacy, Terms, Settings, history, support, both-theme/narrow-wide footer checks and observed artwork decoding. Browser fixtures are not live-provider or physical acceptance.

If a live development server is already part of the authorized validation, `VITE_AUTH_ENABLED=true npm run check:auth -- --dev-url http://127.0.0.1:8080` checks live dev/build agreement. A production preview lacks `/__app-env`; exit 2 means unobserved, not agreement. Do not start an unnecessary development server or substitute its result for production rendering.

## Publication-day command: exact, real clock, fail closed

Immediately before an authorized production-changing step, from the frozen checkout run:

```sh
node scripts/check-legal-release.mjs --publication --authorized-date=2026-10-19 --publication-time-zone=America/Chicago
```

Or use the provided source-bound wrapper, using the frozen PR82 R2 full SHA and tree below (a changed or integrated source needs new validation and approval, then its own exact binding):

```sh
bash /absolute/path/to/REAL-CLOCK-PUBLICATION-GUARD.sh /absolute/path/to/repo cf18ff1c5a56ecf59f8006d4f7c83fb289f393df 6300c1061a790d84447bb92166f340aec895757b
```

Literal placeholder values are rejected. Keep evidence/logs outside the checkout. Keep the wrapper and `VERIFY-TRACKED-SOURCE.py` together. The wrapper verifies exact head/tree and a clean worktree, rejects hidden assume-unchanged/skip-worktree files and submodules, fails if Git inspection fails, and compares every tracked regular file's actual bytes and executable mode with the reviewed tree (bypassing stat-cache cleanliness assumptions), honoring only the exact committed `android/gradlew.bat` CRLF normalization. Other attribute rules need review; no arbitrary Git clean filter is executed. It then prints genuine current UTC/Chicago time, then executes the exact repository CLI above. Its successful exit proves only that source metadata and that observed current date pass the guard. It does not prove authorization, fresh remote refs, CI, deployment configuration, recovery eligibility or user acceptance.

Expected current October 17 result: HOLD. After finalized published metadata is present, the genuine-clock failure must be the out-of-window assertion. Do not fake a current-day pass. Isolated boundary unit tests may exercise October 19 with synthetic dates, but must be labelled unit tests only.

Repeat the guard after any wait or source change and immediately before each separately approved merge/promotion/deployment action. If merging triggers automatic production deployment, the guard and every release gate must precede the merge. A successful check does not stay valid indefinitely. No clock-driven source activation, scheduled merge or automatic October 19 release is installed by this packet. The guard is not wired into every deployment route; branch deployment suppression alone is not a universal guarantee.

If the deployment cannot become publicly effective before 2026-10-20T05:00:00Z, HOLD. Obtain a new date/timezone decision, change all matching source metadata and wording, freeze a new source, repeat applicable validation and obtain exact-source release approval. Retire this October 19 command/packet and prepare a new date-bound command from the new explicit decision. Do not backdate, silently advance the date or reuse an old guard PASS. If a previously approved deployment is already running across the boundary, do not take an unapproved cancel/rollback/settings action: alert the owner, record actual delivery time, and request the necessary containment decision. A public exposure is retained as history even if unintended.
