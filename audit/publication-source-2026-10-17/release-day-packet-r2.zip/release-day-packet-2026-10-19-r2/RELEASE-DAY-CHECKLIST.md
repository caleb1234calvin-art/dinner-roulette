# Pick For Us: October 19 release-day operator packet, R2

Prepared October 17, 2026. **Plan only. NO MERGE, DEPLOYMENT OR ROLLBACK AUTHORIZED.** No current publication, scheduled release or physical-device PASS is claimed.

Repository: `caleb1234calvin-art/dinner-roulette`.

## What changed since the preserved plan

The owner has now confirmed intended October 19, 2026 and the explicit IANA zone `America/Chicago`, conditional on readiness and a later exact-source deployment decision. A new isolated publication-source candidate is frozen as PR82 R2 from preserved R1. R2 corrects two footer-test files after the retained R1 hosted suite had 330 PASS / 20 stale unpublished-label FAIL; application, policy metadata and publication guard are unchanged. New hosted evidence is still required for R2. Its `published` source status/date describe the intended release presentation; they do not establish public publication. The current policies in production have not been replaced by this preparation.

This packet replaces only the old plan's unresolved date/zone and final-source preparation steps. The existing controlled physical test path, 36-case NOT RUN ledger, debug-certificate incompatibility and separate native/Play gates remain in force. Read the preserved plan for the complete physical instructions. Do not rewrite its historical tentative-date record as an earlier approval.

- Confirmed local calendar day: October 19, 2026, America/Chicago (UTC−05:00).
- Earliest permissible day boundary: **2026-10-19T05:00:00Z inclusive**.
- End boundary: **2026-10-20T05:00:00Z exclusive**.
- No precise release time has been selected or approved. Select an attended time inside this outer interval, with time for completion and prompt acceptance.
- October 19 is not mandatory. Unready, unapproved, out-of-window or unverified means **HOLD**.
- No automatic activation at midnight, timer, scheduled merge/deploy or automatic rollback is created. The CLI is an operator check, not universal enforcement of every deployment route.

## 0. Fill the exact source and decision record

Before seeking release approval, fill `RELEASE-RECORD.json` using fresh evidence, never an inferred value:

- final candidate PR/branch, full head SHA, full tree SHA, parent and complete changed-file scope;
- exact candidate validation receipt, independent review, tested source/build fingerprints, CI run/job IDs and original artifact manifests;
- intended integration method and resulting release source/tree. If integration creates or changes source, repeat applicable validation on that exact result before publication. Do not assume a PR-head or synthetic merge build certifies a later result;
- UTC/Chicago release time, actual source/deployment and alias map after publication;
- separate owner release approval and any separately scoped recovery approval, each with message/reference and boundaries.

`candidate-binding.json` records frozen draft PR82 R2, head `cf18ff1c5a56ecf59f8006d4f7c83fb289f393df`, tree `6300c1061a790d84447bb92166f340aec895757b`, branch `integration/legal-publication-source-2026-10-19`, sole parent preserved R1 `9e84b3ef5c5870774e6f7dbfbe1c2c1afa03668a`. At this packet checkpoint local source validation and 91 independent adversarial controls passed; genuine-clock operational guard is EXPECTED HOLD. Fresh hosted web/Android acceptance remains PENDING, not inherited. Replace any remaining blocking evidence fields using actual results; source freeze is not release authorization. No prior PR80/PR81/R1 acceptance transfers automatically. If head, tree, code, configuration, build inputs, approval target or production baseline changes, stop and reconcile before proceeding.

## 1. Fresh attended preflight on October 19

Record a fresh observation time for every item. A read from October 17 is background only.

1. **Authority and operator availability.** Obtain explicit owner approval of the exact candidate and integration/release target before any merge/deploy. Confirm an available operator for immediate web checks and an owner phone session when safe. Website publication can precede Play. If the owner requires physical combined acceptance before any exposure, HOLD for a separately approved isolated testing arrangement; the production-origin wrapper cannot show unpublished candidate pages.
2. **Clock and date guard.** Verify the real UTC clock and Chicago date. Run the exact command in `GUARD-AND-VALIDATION-COMMANDS.md` with the actual current clock. Preserve stdout/stderr and exit code. Repeat immediately before any production-changing step and after waits. A test fixture's synthetic-date PASS is not this gate. Never bypass a failed guard.
3. **Fresh main/candidate.** Read current GitHub main ref, candidate PR head/base, draft/merged state and exact tree. Compare to approved and validated values. Recheck for intervening changes or unexpected auto-merge. Read the complete candidate delta and configured deployment route. If main has changed, HOLD for integration and validation; do not silently use old main or broaden the candidate.
4. **Exact-source CI.** Inspect terminal workflow runs and every required job/aggregate on the exact candidate and intended integration source, recording the actual checked-out source, synthetic merge SHA if used, workflow revision and artifact source-revision/build proof. Pending, canceled, stale or unexplained skipped jobs remain gaps. Existing expected protected-signing SKIPPED and native test NO-SOURCE are explicit qualifications, not passes. Verify independently reviewed legal/footer artifacts and current full-source build bindings. Preserve original archives/hashes before retention expiry.
5. **Migration-free production route.** Read the actual saved Vercel project build override and effective deployment configuration without editing/saving. Expected override ON and full command: `VITE_AUTH_ENABLED=true node scripts/with-app-env.mjs node node_modules/vite/bin/vite.js build --mode production`. Check that no repository-level override supersedes it. `npm run build` chains `db:migrate` and is forbidden. The normalized project connector historically did not expose the override, so a generic project read is insufficient. If the full current route cannot be verified through an authorized interface, HOLD. No setting correction is authorized by this packet.
6. **Current production and all five routes.** Read project `prj_Duz6oRktFrLVIMK1DfAxZyxQCCwm` under team `team_iBSXkvS9Z7tu8o8AtW0vlDt7`, current production deployment ID/status/source, and each alias separately. Record redirect/error fields and actual public response. A deployment's historical alias array is not an independent current alias read. Expected aliases are below. Unexpected split routing or source means HOLD.
7. **Recoverability and authority, separately.** Identify the freshly current deployment as the candidate recovery target after release; verify retention/availability and supported recovery eligibility and actor permissions through an authorized route. A READY record proves neither eligibility nor execution ability. Preserve the prior `rollbackCandidate` API 403; do not retry it via another tool, token, CLI or endpoint to evade denial. If a permitted owner inspection is needed, request it, retain its provenance and limits. Do not click final rollback/promotion controls. Require an explicitly approved recovery scope before automatic or conditional execution; source/date approval does not cover rollback.
8. **Recovery coverage.** Record exactly which aliases the supported mechanism says it can restore. Historic owner-interface evidence covered the apex, www and wrapper runtime; generated project/branch aliases were not verified. Do not claim all-five recovery from it. If coverage remains limited, disclose the residual failure mode and obtain the owner's explicit bounded decision or HOLD. Any alias changes or different recovery mechanism require separate authorization.
9. **Legal/support operations.** Verify candidate Privacy, Terms and history all match version 1.0, `published` source status, effective date 2026-10-19, publication zone America/Chicago and null proposal, with initial/no-forced-assent behavior. Verify Settings uses the same finalized label. Confirm the stated owner-operated support/privacy process at causticrelay@gmail.com remains accurate. This is a technical consistency check, not a legal-compliance certification or inbox-monitor setup.

### All-five alias checklist

For every alias, capture before and after: current resolved deployment/source, HTTP status, redirect destination, alias error and observation UTC time. Verify each independently.

1. `pickforus.app`: canonical production.
2. `www.pickforus.app`: expected 308 redirect to `pickforus.app`; test representative `/privacy` and `/terms` paths retain the intended destination/path.
3. `dinner-roulette-chi.vercel.app`: actual installed-wrapper runtime origin.
4. `dinner-roulette-minions-9e2c.vercel.app`: generated project alias.
5. `dinner-roulette-git-main-minions-9e2c.vercel.app`: generated main-branch alias.

Source/deployment binding requires authoritative deployment/alias metadata plus actual rendered checks. A footer/date string alone does not identify a full Git commit. A successful HTTP response alone does not establish correct policy content. Do not claim that public headers expose a source SHA if they do not.

## 2. Exact approval request, only after the record is filled

The following is a template, not an answered request. Replace every bracketed field using current evidence and disclose all unresolved qualifications. Ask one bundled question with separately named scopes, so the owner can approve release while declining recovery or vice versa.

“Do you approve merging [PR, exact full head/tree] by [integration method and exact resulting source/tree] and deploying that exact validated source to Pick For Us production during [attended time, October 19 America/Chicago, UTC equivalent]? This publishes Privacy Policy and Terms 1.0 dated October 19 and the combined footer/Settings presentation to web visitors and installed wrappers loading dinner-roulette-chi.vercel.app. New hosted phone/tablet checks are still pending, and [specific remaining limitations] remain. The production route is migration-free; no settings, database migration, signing, package registration or Play action is included.

Separately, do you approve using [named supported recovery mechanism] to return [explicit covered aliases] to [freshly verified deployment ID and source] only if this release causes wrong/unreadable legal pages, core discovery/navigation failure, severe blank/crash behavior or suspected data loss? [State uncovered aliases and restoration limits.] Restoring the previous website may remove the new legal routes, and cannot erase the fact that publication occurred. Any different target, alias correction, source hotfix, setting change or continuing legal-page recovery requires another decision.”

Do not imply a plain “date confirmed” or “source ready” response answers this request. If integration source cannot yet be fixed without a production-triggering merge, stop and design a separately authorized path that allows source validation before exposure. Never merge first merely to find out what will deploy.

## 3. Release only the approved exact source

This packet supplies no mutation command. The future operator must use only the specifically approved release mechanism. If merge itself triggers deployment, all applicable preflight and approval must precede merge. No separate deploy-button assumption is safe.

Immediately before the production-changing action: repeat the real-clock publication guard, candidate/main source reads and approved target comparison. If the operation will not finish within the confirmed day, HOLD. After the approved operation record deployed source, actual merge SHA where applicable, deployment ID/URL, status and build route; monitor that bounded operation until terminal, rather than treating submission as success. Unexpected settings/migration/signing/permission prompts are blockers, not implicit approval.

Record actual first public observation in UTC and Chicago, plus any provider-reported routing timestamp and its meaning. Do not assert an exact first-public instant from a later browser observation alone. Preserve full published policy text/metadata and source/build evidence as immutable release history. The publication date is the actual approved date; it is never inferred from PR creation, build time or the intended date.

## 4. Immediate post-publication acceptance

Run promptly while the operator is available. Record PASS, FAIL, BLOCKED or NOT RUN per case with evidence and actual source/deployment/time. **No cases in this packet are already passed.**

1. Independently re-read all five aliases, source bindings and www 308, then GET representative live pages on all routes. Confirm the exact approved release, no split old/new policy and no alias error. Canonical and wrapper origins must receive full legal acceptance below. Unreachable or unobserved aliases stay qualified.
2. Open `/privacy` and `/terms` directly in fresh unsigned browser sessions at canonical and wrapper origins, with JavaScript enabled and disabled. Both return full policy text without sign-in, correct version 1.0, date October 19, 2026 and America/Chicago label. Confirm no unintended Prepared/Draft/Tentative/Not effective wording in current-policy presentation. Historical review-draft text remains historical and must not be rewritten.
3. Compare the complete policy content, section order/anchors, contact address and version-history content to the frozen source. Initial history correctly says there are no previous published versions; the old review draft is not invented as a former effective policy. Current source has initial publication, no material-change notice or forced assent/checkbox. Reading, dismissal and continued use are not consent/agreement evidence.
4. Open Settings. Confirm the same current version/date/zone label, working Privacy/Terms links and Back to Settings return. Test browser Back/Forward and close/reopen through relevant footer/options/plan flows, including interrupted/repeated navigation. Check disabled-JavaScript policy history remains accessible; do not pretend every interactive Settings function works without JavaScript.
5. Verify footer on Home, Dinner, Nightlife, Casino, Date Night, Settings, legal pages and representative result/options/plan surfaces in both themes and narrow/wide layouts. Confirm visible artwork actually decodes, footer links are reachable, text is readable and navigation/keyboard/system bars do not obstruct controls. A screenshot slot or fixture pass alone is not live artwork acceptance.
6. Exercise bounded live core-web discovery using an ordinary manual public city; record selected mode/search/time. Verify usable results or honest no-results/provider-failure UI, close/return and state preservation. Do not generalize one observation to all providers, venues or all accessibility criteria.
7. Check footer Support and policy/Settings contact resolve to causticrelay@gmail.com and expected subject where supplied. On an actual device open the mail handler only within the agreed session and cancel without sending. Missing native mail apps are recorded, with visible-address fallback, not faked by uninstalling an app. Open Maps/venue links and return without ordering, booking, navigating a trip or wagering.
8. Verify saved state remains and initial 1.0 does not force a notice. Use fresh test sessions, never clear meaningful owner data or manipulate live version/storage state to simulate future legal updates. Future material notice and agreement/consent scenarios belong in the isolated harness.

Website acceptance requires intended source/aliases, public full correct legal documents, consistent Settings/history/support, bounded footer/core smoke, no unauthorized mutation and recorded recovery evidence/qualifications. It does not imply phone/tablet, exact APK, signed-update or Play acceptance.

## 5. Actual hosted Android acceptance after release

The website may precede Play. The existing wrapper loads the production website, so website publication immediately affects it too. Use the preserved owner-session card after the public release is checked, at a time the owner is stationary and available. Record actual native wrapper evidence and hosted source separately.

The copied `PHYSICAL-OBSERVATION-LEDGER.csv` retains all 36 cases as NOT RUN: 18 for the Samsung phone and 18 for Galaxy Tab A7 Lite SM-T220. Complete only cases actually observed; unavailable tablet, permission modes or TalkBack stay NOT RUN/BLOCKED. Prior PR78 physical observations and PR80/PR81 builds do not count as new hosted-source acceptance.

PR78, PR80 and PR81 debug APKs share package/version but have different development signing certificates. Do not install one over another or uninstall/clear data to bypass a conflict. Prefer the already confirmed wrapper for hosted-web tests. A future new candidate APK, if any, needs its own identity/signature assessment before a separately approved install. No clean-device/package-absence assumption is allowed. Same-package compatible-signer update and Play-delivered certificate/install remain separate future cases.

Preserve owner data, stop on black screen/crash, trapped navigation, suspected data loss or unexpected replacement/security prompts. The historical intermittent offline/cross-app connectivity incident remains unresolved by a few successful cycles. No VPN/security/network-setting workaround is authorized. Location, accessibility or installation changes require the corresponding owner-approved scope.

## 6. HOLD, failure and recovery

**Before exposure:** HOLD for missing approval, outside date window, changed source/main, nonterminal/invalid CI, unsafe or unreadable build route, unverified required aliases/recovery, or unavailable immediate acceptance. Keep the isolated source unmerged and deployment-disabled.

**Missed day:** At or after 2026-10-20T05:00:00Z the October 19 guard must fail. Ask for a new intended publication date/timezone, update all matching source metadata/wording in a new candidate, rerun affected exact-source validation, then seek new exact-source release approval. Retire this October 19 packet and prepare the new explicitly authorized date-bound guard. Do not backdate, silently roll forward or claim an earlier guard result remains valid. October 19 is not a mandatory deadline.

**After exposure:** Wrong source/date, incomplete or login-gated policies, wrong support recipient, severe navigation/footer obstruction, attributable core failure, blank/crash behavior or suspected data loss requires prompt escalation. Preserve redacted evidence and distinguish a new hosted regression from a pre-existing native issue or provider outage. Use only an already approved recovery target/mechanism/alias scope if its conditions are met; otherwise ask before acting. Diagnosis does not authorize a different deployment, hotfix, database action or alias edit.

Freshly reverify recovery availability/permissions immediately before executing any approved rollback. Afterward check every alias and actual wrapper runtime again; generated/branch aliases may need separately approved correction. A visible confirmation control or READY target is not a successful rollback. Record actual terminal result, restored source and remaining gaps.

A rollback does not erase publication. Retain the full policy text, source and actual exposure dates/times. Never reset a real published history to “never published” or overwrite a published snapshot. Returning to the old website may remove policy routes and reintroduce the known missing-policy problem; disclose that and seek a separately reviewed way to maintain correct legal access. This packet grants no such recovery modification authority.

## Background references, not fresh release-day clearance

As reported by the continuity worker at approximately 07:23 UTC October 17:

- main `c3208d9fdc9a21d698efa9254be1286f5d3d2836`;
- PR81 remains draft/unmerged at `7098b4cbf0e27761fdbb9a9cc1e64f3aef963c94`;
- canonical preparation checkpoint `e5d0dc7fa2b45f65f9b97f1159c6c698a8ff4de6`;
- apex deployment read resolves `dpl_FMS2SBg4ymuDwU4avpywV6yB5vg6`, READY, source c3208…, aliasError null, with five expected aliases in metadata. That read is not a new independent five-alias routing test;
- older `dpl_8DBJFLQwkBGckTxM5RYPM63dLqS5` remains READY, source `ead2319c4869478f4cd121e2370db4d9734d83ed`, but is not automatically the correct/eligible next rollback target;
- FMS would be the likely immediately prior deployment after the proposed release only if fresh reads establish that. Current build-override and supported recovery eligibility were not freshly inspected by this worker. Historical 403 and generated-alias qualifications remain.

Source: [canonical preparation checkpoint](https://github.com/caleb1234calvin-art/dinner-roulette/commit/e5d0dc7fa2b45f65f9b97f1159c6c698a8ff4de6); preserved dated plan and source bindings are included in the companion reference record. Current final candidate binding is deliberately separate.
