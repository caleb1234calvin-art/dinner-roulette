# October 19, 2026 release-day packet: R2

This is a prepared operational packet for Pick For Us. It does not publish anything or authorize merge, deployment, recovery, migrations, settings, signing, installation or Play actions.

- Frozen candidate: draft PR82 R2, `cf18ff1c5a56ecf59f8006d4f7c83fb289f393df`, tree `6300c1061a790d84447bb92166f340aec895757b`.
- Confirmed intended day: October 19, 2026 in America/Chicago. UTC interval: October 19 05:00 inclusive to October 20 05:00 exclusive.
- Local source validation and independent source controls are recorded in the freeze receipt. Fresh hosted source acceptance is pending at this packet's freeze checkpoint and must be read from its later final receipt. An independent guard review is retained separately.
- A genuine October 17 publication-day command must HOLD. No current policies, scheduled activation or release-day PASS are claimed.
- All 36 physical cases remain NOT RUN. Existing native signer/update restrictions and Play gates remain separate.

R2 corrects two footer-test files after the retained R1 hosted suite had 330 PASS / 20 stale unpublished-label FAIL. Application, policy metadata and publication guard are unchanged. See `R2-CHANGE-ADDENDUM.md`; the complete R1 packet/archive remains preserved.

## Start here

1. Read `RELEASE-DAY-CHECKLIST.md` for ordered gates, approval boundaries, post-publication acceptance and the missed-day/recovery path.
2. Read `GUARD-AND-VALIDATION-COMMANDS.md`. Keep `REAL-CLOCK-PUBLICATION-GUARD.sh` and `VERIFY-TRACKED-SOURCE.py` together. They perform local source/time checks only.
3. Use `candidate-binding.json` and `RELEASE-RECORD.json` to bind actual source, approvals, CI/build, current production, aliases and recovery evidence. Null fields are pending, not passed.
4. After separately approved and verified website publication, use `OWNER-SESSION-CARD.md` and `PHYSICAL-OBSERVATION-LEDGER.csv` for real phone/tablet observations.
5. `review/` preserves the independent guard review, original findings, corrections and scoped test evidence. `references/` contains unchanged historical plan/signature references; historical wording does not supersede the new date confirmation.

The future release must use current evidence. This packet is not a substitute for a fresh real-clock guard, exact-source owner approval, verified production build route, all-five routing checks or supported recovery eligibility/permissions.
