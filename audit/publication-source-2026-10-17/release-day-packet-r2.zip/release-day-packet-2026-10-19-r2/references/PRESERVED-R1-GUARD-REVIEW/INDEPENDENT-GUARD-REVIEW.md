# Independent operational guard review

**Verdict: review complete; the corrected guard is fit for its documented read-only date/source check. No unresolved defect remains in the reviewed scope. Operational publication remains HOLD.**

Final binding: PR82 HEAD `9e84b3ef5c5870774e6f7dbfbe1c2c1afa03668a`, tree `c897ee704ac9cb84011d1e54027b9d3e2a29a12a`, clean before and after review. At genuine `2026-10-17T07:33:02.662Z` (02:33:02 CDT), the wrapper verified 1,486 tracked files / 78,127,368 checkout bytes and exited 1 specifically because October 17 is outside the approved October 19 calendar day. No operational PASS was obtained or fabricated.

All 19 isolated guard regressions and all 9 final-source legal-release unit tests pass. The guard correctly rejects corrupt Git inspection, wrong/dirty/hidden source, stat-cache-hidden edits, hidden executable-mode changes, submodules, and unsupported/nested attributes. The exact reviewed CRLF rule for `android/gradlew.bat` is honored without executing clean filters; a concealed same-size content edit in that file is still rejected. Unit date-conversion evidence remains clearly labelled separately.

Exact reviewed file hashes and evidence bindings are in `FINAL-GUARD-REVIEW-RECEIPT.json`. This source/guard review is not final hosted CI acceptance. Full build/CI/browser/physical acceptance and every release/recovery approval remain outside this review.

Review started 2026-10-17 07:26 UTC. Scope: the release-day wrapper and command sheet, with read-only inspection of the publication source candidate. This is a technical guard review, not permission to release.

## Findings and correction history

1. **Fail-closed Git status error is not enforced.** The original wrapper evaluates `[[ -z "$(git status --porcelain --untracked-files=all)" ]]`. A failed `git status` with empty stdout makes this test succeed. In an independent temporary fixture, a corrupt Git index produced a fatal status error but execution continued to the real-clock publication checker. The October 17 date gate still failed, so no live PASS was obtained or fabricated. Capture status separately, explicitly reject a nonzero command result, then test the captured output. See `fixture-status-error-original.log`.
2. **Hidden tracked changes evade the original source binding.** Git assume-unchanged (or skip-worktree) flags can conceal worktree edits while HEAD/tree and porcelain status appear correct. A harmless comment added to the fixture's validator under assume-unchanged was not rejected before the current-date checker. Reject these flags and unsupported sparse/submodule layouts, or verify actual tracked bytes against the reviewed tree. See `fixture-assume-unchanged-original.log`.
3. **Minor CLI spelling mismatch.** The optional auth command uses `--dev-url=http://127.0.0.1:8080`, but `check-auth-invariant.mjs` accepts `--dev-url http://127.0.0.1:8080`. The current example happens to fall back to the identical default URL, but the supplied option is ignored. Use the supported separated argument form.

Original file SHA-256 values:
- REAL-CLOCK-PUBLICATION-GUARD.sh: `02af036dc43ff1afdc49d69a4ce123ae0dcb1c522eec27c0a4967dadad0ee79b`
- GUARD-AND-VALIDATION-COMMANDS.md: `2334a57450a8692e8febc5ae7f6ccfdda9a48a4ec4cefb1f5a3a30bcc5e8024c`

## Confirmed correct scope and behavior

- The exact repository publication command is `node scripts/check-legal-release.mjs --publication --authorized-date=2026-10-19 --publication-time-zone=America/Chicago`. The parser accepts these flags, rejects duplicate/unscoped/unknown flags, and provides no CLI clock override. The exported validator's injected `now` is used in explicitly labelled unit tests only.
- Independent Python zoneinfo conversion confirms the Chicago day is UTC−05:00 and the half-open UTC interval is `[2026-10-19T05:00:00Z, 2026-10-20T05:00:00Z)`. `independent-chicago-boundary-unit.json` is UNIT EVIDENCE ONLY, never live release authorization.
- With current finalized-form metadata copied into a clean, independent fixture, the actual host clock produced the specific expected October 17 out-of-window HOLD. No clock was set, injected, or overridden. This fixture result is not final-source validation.
- `package.json` confirms ordinary `npm run build` also runs `npm run db:migrate`. The command sheet correctly forbids it and specifies the reviewed direct Vite build through `with-app-env.mjs` instead. The build proof's capture/complete/verify commands exist. It binds only its selected input paths and output bytes, not the full Git tree, environment, dependency provenance, deployed state, or release authority.
- The provided wrapper performs local inspection and the date/source check only. It contains no merge, deploy, settings, migration, signing, install, Play, rollback, scheduler, clock-setting, or source-writing operation. Git status can perform normal local index-refresh bookkeeping; this is not a deployment action.
- The commands correctly retain missing/failed CI, skipped signing, native NO-SOURCE tasks, browser fixtures, production preview auth-indeterminate results, and physical/live-provider acceptance as distinct limitations.
- A guard PASS would remain an instantaneous check in a trusted environment, not an atomic lock on future source or clock state. Fresh owner approval and every production gate are still required immediately before each authorized action. The wrapper is not universally installed in deployment routes.

## Retest progress

- The first three findings were corrected. A 13-case isolated regression suite passed, including fail-closed corrupt index, hidden flags, dirty files, invalid binding and genuine-clock October 17 HOLD.
- A further same-size, preserved-mtime edit with `core.trustctime=false` and `core.checkStat=minimal` demonstrated that porcelain status alone still misses actual source changes. Evidence: `fixture-stat-cache-original.log`. The parent added direct tracked-blob hashing and executable-mode verification in `VERIFY-TRACKED-SOURCE.py`, with no Git replacement objects, unsupported-file-type rejection and change-during-read checks. A 15-case regression suite then passed, including the stat-cache and unsupported-submodule cases.
- On the actual final source, the new raw-byte helper rejected `android/gradlew.bat`: reviewed `.gitattributes` intentionally checks it out as CRLF although its Git blob contains LF. Normalizing its 94 CRLF pairs gives the exact committed blob. The source was not changed. The parent corrected this with a narrowly scoped reviewed EOL conversion; no arbitrary clean filter is executed. Original evidence: `final-source-crlf-helper-original.log`.
- Frozen final-source binding is PR82, HEAD `9e84b3ef5c5870774e6f7dbfbe1c2c1afa03668a`, tree `c897ee704ac9cb84011d1e54027b9d3e2a29a12a`. The direct metadata check passed, all 9 legal-release tests passed, and the actual-current-date direct CLI failed specifically on the October 17 versus October 19 assertion. These checks did not modify source.
- The complete RELEASE-DAY-CHECKLIST.md was inspected for command/authority contradictions. No additional defect was found in its separate release/recovery approvals, all-five-alias qualification, denial-respecting recovery checks, migration-free route, publication history retention, or physical NOT RUN/signing qualifications.

## Current review state

Complete. The narrowly scoped EOL correction was inspected and the 19-case regression suite rerun successfully. The actual final-source wrapper reached the expected real-clock out-of-window HOLD. No production authority is created by this review. The source candidate remains under another worker's control and has not been modified by this reviewer. No production-changing action, migration, signing, installation, Play submission, or rollback was performed.

## Final reviewed file SHA-256 values

- `REAL-CLOCK-PUBLICATION-GUARD.sh`: `11b1a81cc8b13a51fdf65d41b65e6a746d60b97c4b66f5938e17c9e57d0e3016`
- `VERIFY-TRACKED-SOURCE.py`: `0b9b524a120e6f545287fdc622e1fcf3a3ffd69cb5543baf51321c848e809457`
- `GUARD-AND-VALIDATION-COMMANDS.md`: `4ee533392eac599b747c2cf81563ce15e1b79febd178fbe9cd6089120acd8b89`
- `RELEASE-DAY-CHECKLIST.md`: `4a215612ee461456ff61b93644d9b1f9bb22bf8424bca585660779c9733fbb40`

Final documentation includes the missed-window rule: retire this October 19 packet/command and prepare a newly authorized date-bound guard. This clarification introduces no clock bypass or release authority.
