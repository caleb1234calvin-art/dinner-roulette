"""Independent local negative-path regression checks; NEVER substitute a clock.

Uses throwaway local Git repositories containing copied validator/metadata files.
The live-calendar control intentionally expects HOLD on October 17, 2026.
No production source or remote Git state is changed.
"""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tempfile
import os
import time
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
PACKET = HERE.parent
SOURCE = PACKET.parent / 'publication-source-candidate'
GUARD = PACKET / 'REAL-CLOCK-PUBLICATION-GUARD.sh'
ROOT = Path(tempfile.mkdtemp(prefix='release-guard-negatives-'))
SEED = ROOT / 'seed'
SEED.mkdir()

def call(args, cwd=None):
    return subprocess.run(args, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

def git(repo, *args):
    r = call(['git', '-C', str(repo), *args])
    if r.returncode:
        raise RuntimeError(r.stdout)
    return r.stdout.strip()

for name in ['.gitattributes','android/gradlew.bat','scripts/check-legal-release.mjs','src/lib/legal/history.json','src/lib/legal/documents.json']:
    p = SEED / name
    p.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(SOURCE / name,p)
git(SEED,'init','-q')
git(SEED,'add','.')
git(SEED,'-c','user.name=Independent Guard Test','-c','user.email=guard-review@example.invalid','commit','-q','-m','Isolated guard negative-path fixture')
HEAD = git(SEED,'rev-parse','HEAD')
TREE = git(SEED,'rev-parse','HEAD^{tree}')
results=[]

def check(name, args, expected_fragment=None, expected_status=None, setup=None, before_clock=True):
    repo = ROOT / name
    shutil.copytree(SEED, repo)
    if setup: setup(repo)
    argv=args(repo) if callable(args) else args
    r=call(['bash',str(GUARD),*map(str,argv)])
    good=r.returncode != 0 and 'DATE/SOURCE GUARD PASS ONLY.' not in r.stdout
    if expected_fragment is not None: good &= expected_fragment in r.stdout
    if expected_status is not None: good &= r.returncode == expected_status
    if before_clock: good &= 'checkedAtUtc' not in r.stdout
    entry={'name':name,'passed':bool(good),'exitCode':r.returncode,'expectedFragment':expected_fragment,'expectedStatus':expected_status,'requiresStopBeforeClock':before_clock,'output':r.stdout}
    results.append(entry)
    (HERE / f'negative-{name}.log').write_text(r.stdout)
    print(('PASS' if good else 'FAIL') + ': ' + name + ' (exit ' + str(r.returncode) + ')')

normal=lambda repo:[repo,HEAD,TREE]
check('usage',[],expected_status=64)
check('relative-path',['relative/path',HEAD,TREE],expected_status=64)
check('placeholders',lambda r:[r,'EXACT_HEAD','EXACT_TREE'],expected_status=64)
check('missing-repository',lambda r:[r/'absent',HEAD,TREE])
check('nested-directory',lambda r:[r/'scripts',HEAD,TREE],expected_fragment='repository root')
check('wrong-head',lambda r:[r,'0'*40,TREE],expected_fragment='HEAD differs')
check('wrong-tree',lambda r:[r,HEAD,'0'*40],expected_fragment='tree differs')
check('tracked-edit',normal,setup=lambda r:(r/'scripts/check-legal-release.mjs').open('a').write('\n// Safe isolated test edit.\n'))
check('untracked-file',normal,setup=lambda r:(r/'unexpected.txt').write_text('Safe isolated test file.\n'))
check('corrupt-index',normal,setup=lambda r:(r/'.git/index').write_bytes(b'x'))
def hidden_edit(repo,flag):
    git(repo,'update-index',flag,'scripts/check-legal-release.mjs')
    with (repo/'scripts/check-legal-release.mjs').open('a') as f: f.write('\n// Safe isolated hidden-edit test; no clock modification.\n')
check('assume-unchanged',normal,setup=lambda r:hidden_edit(r,'--assume-unchanged'))
check('skip-worktree',normal,setup=lambda r:hidden_edit(r,'--skip-worktree'))
def stat_cache_edit(repo):
    git(repo,'config','core.trustctime','false')
    git(repo,'config','core.checkStat','minimal')
    f=repo/'scripts/check-legal-release.mjs'
    old=time.time_ns()-86_400_000_000_000
    os.utime(f,ns=(old,old))
    git(repo,'update-index','--refresh')
    before=f.stat()
    text=f.read_text()
    text=text.replace("'node:assert/strict'",'"node:assert/strict"',1)
    f.write_text(text)
    os.utime(f,ns=(before.st_atime_ns,before.st_mtime_ns))
check('stat-cache-hidden-edit',normal,setup=stat_cache_edit)
def bat_hidden_edit(repo):
    git(repo,'config','core.trustctime','false')
    git(repo,'config','core.checkStat','minimal')
    f=repo/'android/gradlew.bat'
    old=time.time_ns()-86_400_000_000_000
    os.utime(f,ns=(old,old))
    git(repo,'update-index','--refresh')
    before=f.stat()
    data=f.read_bytes()
    assert b'@rem' in data and b'\r\n' in data
    f.write_bytes(data.replace(b'@rem',b'@REM',1))
    os.utime(f,ns=(before.st_atime_ns,before.st_mtime_ns))
check('crlf-bat-hidden-content-edit',normal,setup=bat_hidden_edit,expected_fragment='tracked source bytes differ')
def hidden_mode_edit(repo):
    git(repo,'config','core.filemode','false')
    f=repo/'scripts/check-legal-release.mjs'
    f.chmod(f.stat().st_mode | 0o111)
check('hidden-executable-mode',normal,setup=hidden_mode_edit,expected_fragment='executable mode differs')
def unsupported_attributes(repo):
    (repo/'.gitattributes').write_text('* text=auto\n')
    git(repo,'add','.gitattributes')
    git(repo,'-c','user.name=Independent Guard Test','-c','user.email=guard-review@example.invalid','commit','-q','-m','Unsupported attributes isolated fixture')
check('unsupported-attributes',lambda r:[r,git(r,'rev-parse','HEAD'),git(r,'rev-parse','HEAD^{tree}')],setup=unsupported_attributes,expected_fragment='Git attributes changed')
def nested_attributes(repo):
    (repo/'scripts/.gitattributes').write_text('*.mjs text eol=lf\n')
    git(repo,'add','scripts/.gitattributes')
    git(repo,'-c','user.name=Independent Guard Test','-c','user.email=guard-review@example.invalid','commit','-q','-m','Nested attributes isolated fixture')
check('nested-attributes',lambda r:[r,git(r,'rev-parse','HEAD'),git(r,'rev-parse','HEAD^{tree}')],setup=nested_attributes,expected_fragment='unsupported nested')
def submodule_fixture(repo):
    git(repo,'update-index','--add','--cacheinfo',f'160000,{HEAD},unsupported-submodule')
    git(repo,'-c','user.name=Independent Guard Test','-c','user.email=guard-review@example.invalid','commit','-q','-m','Unsupported isolated gitlink fixture')
check('submodule-source',lambda r:[r,git(r,'rev-parse','HEAD'),git(r,'rev-parse','HEAD^{tree}')],setup=submodule_fixture,expected_fragment='submodule')
check('clean-real-clock-hold',normal,expected_fragment='Publication HOLD: not the authorized calendar day',before_clock=False)
report={'kind':'ISOLATED LOCAL NEGATIVE-PATH TESTS; real host clock, no clock override', 'checkedAtUtc':datetime.now(timezone.utc).isoformat(),'guardSha256':hashlib.sha256(GUARD.read_bytes()).hexdigest(),'fixtureRoot':str(ROOT),'fixtureHead':HEAD,'fixtureTree':TREE,'allPassed':all(r['passed'] for r in results),'results':results}
(HERE/'negative-path-results.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(0 if report['allPassed'] else 1)
