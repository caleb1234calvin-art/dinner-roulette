# Preserved historical references

These are unchanged copies of the prior plan, PR81 signature addendum and that prior plan's PR80 source binding. Their tentative-date and “current” wording is historical. The owner has since confirmed October 19, 2026 / America/Chicago; the new candidate binding is separate. These copies do not authorize release, transfer predecessor tests, claim current publication or change any physical NOT RUN result.

The current operational packet is `../RELEASE-DAY-CHECKLIST.md`. The full original signature APK/archive evidence remains with the prior retained originals; this packet does not copy or rebuild APKs and makes no signature claim about a future native artifact.
