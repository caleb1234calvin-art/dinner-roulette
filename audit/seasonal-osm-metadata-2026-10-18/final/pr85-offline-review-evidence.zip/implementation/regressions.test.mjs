import test from 'node:test';
import assert from 'node:assert/strict';
import {adaptOsmSeasonalMetadata as adapt} from '../pr85-implementation/scripts/seasonal-osm-metadata.mjs';
const place = tags => ({type:'node',id:7,lat:37,lon:-94,tags});
for (const reverse of [false,true]) {
 test(`same ID negative nonseasonal row must survive filtering (reverse=${reverse})`,()=>{
  const elements=[place({name:'Former Haunt',attraction:'haunted_house'}), place({name:'Former Haunt',shop:'vacant',closed:'yes'})];
  if(reverse) elements.reverse();
  const r=adapt({elements});
  assert.ok(r.status==='coverage-incomplete'||r.proposals.some(p=>p.triage.reasons.includes('conflicting-osm-identity')&&p.triage.reasons.includes('negative-lifecycle-evidence')),JSON.stringify(r));
 });
}
test('historical categories from different lifecycle prefixes must not shadow each other',()=>{
 const r=adapt({elements:[place({name:'Former Farm','disused:attraction':'unknown','demolished:attraction':'haunted_house'})]});
 assert.equal(r.proposals.length,1);
 assert.deepEqual(r.proposals[0].historicalCategoryHints,['haunted-house']);
});
test('historical categories must not combine unrelated lifecycle prefixes',()=>{
 const r=adapt({elements:[place({name:'Former Farm','disused:leisure':'maze','demolished:crop':'corn'})]});
 assert.ok(!r.proposals.some(p=>p.historicalCategoryHints.includes('corn-maze')));
});
