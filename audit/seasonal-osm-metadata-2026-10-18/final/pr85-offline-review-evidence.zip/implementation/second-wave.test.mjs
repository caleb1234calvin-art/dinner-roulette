import test from 'node:test';
import assert from 'node:assert/strict';
import { adaptOsmSeasonalMetadata as adapt } from '../pr85-implementation/scripts/seasonal-osm-metadata.mjs';
const row = tags => ({type:'node',id:7,lat:37,lon:-94,tags:{name:'Synthetic',attraction:'haunted_house',...tags}});
for (const value of [undefined,()=>{},Symbol('tag')]) test(`lossy ${typeof value} rejected`,()=>{
 assert.equal(adapt({elements:[row({note:value})]}).status,'malformed-response');
});
for(const prefix of ['destroyed','razed']) test(`${prefix} retained`,()=>{
 const r=adapt({elements:[row({attraction:'', [prefix+':attraction']:'haunted_house'})]});
 assert.equal(r.proposals.length,1);
 assert.deepEqual(r.proposals[0].activityHints,[]);
 assert.ok(r.proposals[0].triage.reasons.includes('negative-lifecycle-evidence'));
});
test('false prefixed lifecycle does not imply negative',()=>{
 assert.deepEqual(adapt({elements:[row({'disused:attraction':'no'})]}).proposals[0].mappedLifecycleConcerns,[]);
});
test('full address preserved',()=>assert.equal(adapt({elements:[row({'addr:full':'12 Synthetic Road'})]}).proposals[0].proposedAddress,'12 Synthetic Road'));
test('identical rows not called conflict and reasons unique',()=>{
 const r=adapt({elements:Array.from({length:100},()=>row({}))});
 assert.ok(r.proposals.every(p=>!p.triage.reasons.includes('conflicting-osm-identity')));
 assert.ok(r.proposals.every(p=>p.triage.reasons.length===new Set(p.triage.reasons).size));
});
