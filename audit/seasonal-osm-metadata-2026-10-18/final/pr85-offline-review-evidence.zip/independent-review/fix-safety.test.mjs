import test from 'node:test';
import assert from 'node:assert/strict';
import {adaptOsmSeasonalMetadata as adapt} from '../pr85-implementation/scripts/seasonal-osm-metadata.mjs';
const p=(id=1)=>({type:'node',id,lat:90,lon:180,tags:{name:'Test',attraction:'haunted_house',website:'https://example.invalid',opening_hours:'24/7',start_date:'2026-01-01'}});
test('JSON byte cap applies at exact UTF8 boundaries',()=>{
 const base=JSON.stringify({elements:[p()],padding:''});
 const exact=base.replace('"padding":""','"padding":"'+'x'.repeat(512000-Buffer.byteLength(base))+'"');
 assert.equal(Buffer.byteLength(exact),512000);
 assert.equal(adapt(exact).status,'metadata-proposals-only');
 assert.equal(adapt(exact+' ').status,'bounded-input-rejected');
 assert.equal(adapt(JSON.parse(exact)).status,'metadata-proposals-only');
 assert.equal(adapt({...JSON.parse(exact),padding:JSON.parse(exact).padding+'é'}).status,'bounded-input-rejected');
});
test('100 vs 101 elements, trailing invalid input, malformed envelopes fail closed',()=>{
 assert.equal(adapt({elements:Array.from({length:100},(_,i)=>p(i+1))}).proposals.length,100);
 assert.equal(adapt({elements:Array.from({length:101},(_,i)=>p(i+1))}).status,'coverage-incomplete');
 assert.equal(adapt({elements:[...Array.from({length:99},(_,i)=>p(i+1)),null]}).status,'coverage-incomplete');
 for(const x of [undefined,null,true,1,[],{},'{',()=>{},1n]) assert.equal(adapt(x).status,'malformed-response');
 const cycle={};cycle.self=cycle; assert.equal(adapt(cycle).status,'malformed-response');
});
test('never fetches URLs or trusts supplied eligibility, dates or website tags',()=>{
 const old=globalThis.fetch; globalThis.fetch=()=>{throw Error('unexpected HTTP')};
 try {
  const x=p();Object.assign(x.tags,{publishable:'true',verified:'true',year2026Verified:'true',openNowEligible:'true'});
  const r=adapt({elements:[x]});const q=r.proposals[0];
  assert.equal(r.publicationEligible,false);
  for(const k of ['publishable','verified','year2026Verified','openNowEligible'])assert.equal(q[k],false);
  for(const k of ['startDate','endDate','openingHours','sourceWebsite'])assert.equal(q[k],null);
  assert.equal(q.license.identifier,'ODbL-1.0');assert.equal(q.osm.elementUrl,'https://www.openstreetmap.org/node/1');
 }finally{globalThis.fetch=old;}
});
