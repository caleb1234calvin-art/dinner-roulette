import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {adaptOsmSeasonalMetadata as f} from '../pr85-implementation/scripts/seasonal-osm-metadata.mjs';
const p=(id,tags={})=>({type:'node',id,lat:37,lon:-94,tags:{name:'Synthetic',attraction:'haunted_house',...tags}});
const hash=s=>createHash('sha256').update(s).digest('hex');
const canonical=x=> x&&typeof x==='object' ? Array.isArray(x)?'['+x.map(canonical).join(',')+']':'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}' :JSON.stringify(x);
test('independent hashes/filtered row pointers survive serialization',()=>{
 const elements=[p(3,{attraction:'',name:'Unrelated'}),p(7),p(7,{attraction:'',destroyed:'yes'}),p(8)];
 const source=JSON.stringify({elements},null,3);const r=JSON.parse(JSON.stringify(f(source)));
 assert.equal(r.provenance.inputSha256,hash(source));
 assert.notEqual(r.provenance.inputSha256,f(JSON.stringify({elements})).provenance.inputSha256);
 assert.equal(r.provenance.sourceRows.length,4);
 assert.deepEqual(r.proposals.map(x=>x.provenance.elementIndex),[1,3]);
 assert.deepEqual(r.proposals[0].provenance.negativeEvidenceIndices,[2]);
 assert.deepEqual(r.proposals[1].provenance.negativeEvidenceIndices,[]);
 elements.forEach((e,i)=>assert.equal(r.provenance.sourceRows[i].recordSha256,hash(canonical(e))));
 assert.equal(f({elements}).provenance.inputSha256,hash(canonical({elements})));
});
test('multiple identities and mixed duplicate/conflict state cannot contaminate each other',()=>{
 const elements=[p(7),p(7),p(7,{name:'Other'}),p(8)];const r=f({elements});
 for(const q of r.proposals.slice(0,3)) assert.ok(q.triage.reasons.includes('conflicting-osm-identity'));
 for(const q of r.proposals.slice(0,2))assert.ok(q.triage.reasons.includes('duplicate-osm-record'));
 assert.ok(!r.proposals[2].triage.reasons.includes('duplicate-osm-record'));
 assert.ok(!r.proposals[3].triage.reasons.includes('conflicting-osm-identity'));
});
test('raw tag UTF8 and key/count bounds fail closed, including irrelevant rows',()=>{
 assert.equal(f({elements:[p(1,{name:'é'.repeat(2048)})]}).status,'metadata-proposals-only');
 for(const tags of [{name:'é'.repeat(2049)}, {['destroyed:'+ 'x'.repeat(151)]:'yes'},Object.fromEntries(Array.from({length:64},(_,i)=>['destroyed:x'+i,'yes']))]) {
  const r=f({elements:[p(1),p(2,{...tags,attraction:''})]});
  assert.equal(r.status,'coverage-incomplete');assert.deepEqual(r.proposals,[]);
 }
});
test('prototype-named tags preserve bytes without prototype pollution',()=>{
 const source='{"elements":[{"type":"node","id":1,"lat":1,"lon":1,"tags":{"name":"Test","attraction":"haunted_house","__proto__":"text","constructor":"text"}}]}';
 const r=f(source);assert.equal(r.status,'metadata-proposals-only');assert.equal(r.provenance.inputSha256,hash(source));assert.equal({}.polluted,undefined);
});
test('non JSON descriptors and values never disappear into accepted fixture',()=>{
 let calls=0;const e={elements:[]};Object.defineProperty(e,'x',{get(){calls++;return 1},enumerable:true});
 const hidden={elements:[]};Object.defineProperty(hidden,'x',{value:1});
 const arr=[];arr.x='extra';
 for(const x of [e,hidden,{elements:arr},{elements:[],x:new Map()}, {elements:[],x:1n}, {elements:[],x:undefined}])assert.equal(f(x).status,'malformed-response');
 assert.equal(calls,0);
});
test('lifecycle false values cannot create negative evidence across same ID',()=>{
 for(const val of ['no','NO','false','FALSE','0',''])for(const prefix of ['disused','was','abandoned','destroyed','razed','removed','demolished']) {
 const r=f({elements:[p(7),p(7,{attraction:'',[prefix+':attraction']:val})]});
 assert.deepEqual(r.proposals[0].mappedLifecycleConcerns,[]);
 assert.deepEqual(r.proposals[0].provenance.negativeEvidenceIndices,[]);
 }
});
