import test from 'node:test';
import assert from 'node:assert/strict';
import {adaptOsmSeasonalMetadata as adapt} from './full-source/scripts/seasonal-osm-metadata.mjs';
const p=()=>({type:'node',id:7,lat:1,lon:1,tags:{name:'Same',attraction:'haunted_house'}});
test('exact duplicates are duplicates, not contradictory identities',()=>{
 const r=adapt({elements:[p(),p()]});
 assert.ok(r.proposals.every(x=>!x.triage.reasons.includes('conflicting-osm-identity')));
});
test('triage reasons are unique even with many same-name rows',()=>{
 const r=adapt({elements:Array.from({length:100},(_,i)=>({...p(),id:i+1}))});
 assert.ok(r.proposals.every(x=>new Set(x.triage.reasons).size===x.triage.reasons.length));
});
for(const [label,value] of [['undefined',undefined],['function',()=>{}],['symbol',Symbol('test')]]) {
 test(`unsupported ${label} tag must not silently disappear`,()=>{
  const x=p();x.tags.closed=value;
  assert.equal(adapt({elements:[x]}).status,'malformed-response');
 });
}
