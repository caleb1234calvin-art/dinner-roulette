import type { SeasonalListing } from "./listing";
import type { SeasonalVenueAvailability, DateNightAvailability } from "./availability";
import type { DecoratedRestaurant, DistanceMiles, Restaurant } from "@/lib/restaurants/types";
import type { DateNightQueryGroupId } from "./query-plan";

export type DateNightTypeId =
  | "anything"
  | "bowling"
  | "arcade"
  | "movies"
  | "mini-golf"
  | "escape-room"
  | "park"
  | "museum"
  | "skating"
  | "haunted-house"
  | "corn-maze"
  | "pumpkin-patch"
  | "other-halloween-fall";

export type ConcreteDateNightType = Exclude<DateNightTypeId, "anything">;

export interface DateNightFilters {
  radiusMiles: DistanceMiles;
  activityTypes: DateNightTypeId[];
  mood: number;
  openNowOnly: boolean;
  favoritesOnly: boolean;
  reduceParks: boolean;
}

export type DateNightLifecycle = "disused" | "permanently-closed";

export interface DateNightEvidence {
  id: string;
  source: "osm" | "catalog";
  activityTypes: ConcreteDateNightType[];
  openingHours: string | null;
  website: string | null;
  lifecycle?: DateNightLifecycle;
}

export interface DateNightPlace extends Restaurant {
  lifecycle?: DateNightLifecycle;
  discoveryEvidence?: DateNightEvidence[];
  seasonalAvailability?: SeasonalVenueAvailability;
  activityTypes: ConcreteDateNightType[];
  moodLevel: 1 | 2 | 3;
  seasonalVisitNotes?: readonly string[];
  seasonalListing?: SeasonalListing;
}

export interface DecoratedDateNightPlace extends DecoratedRestaurant, DateNightPlace {
  availability: DateNightAvailability;
  activityTypes: ConcreteDateNightType[];
  moodLevel: 1 | 2 | 3;
}

export interface DateNightGroupCoverage {
  id: DateNightQueryGroupId;
  activityTypes: ConcreteDateNightType[];
  outcome: "succeeded-nonempty" | "succeeded-empty" | "failed" | "cancelled" | "cache-hit";
  originOutcome?: "succeeded-nonempty" | "succeeded-empty";
}

export interface DateNightSearchResponse {
  venues: DateNightPlace[];
  source: "live" | "merged" | "fallback";
  warning?: string;
  patch?: { id: string; version: string };
  /** Successful empty is coverage, not outage. Cache assembly may split a group
   * into disjoint category slices with different outcomes. */
  discovery?: { groups: DateNightGroupCoverage[]; partial: boolean };
}

export const DEFAULT_DATE_NIGHT_FILTERS: DateNightFilters = {
  radiusMiles: 15,
  activityTypes: ["anything"],
  mood: 50,
  openNowOnly: true,
  favoritesOnly: false,
  reduceParks: true,
};

export const DATE_NIGHT_TYPE_CHIPS: ReadonlyArray<{
  id: DateNightTypeId;
  label: string;
}> = [
  { id: "anything", label: "Anything" },
  { id: "bowling", label: "Bowling" },
  { id: "arcade", label: "Arcade" },
  { id: "movies", label: "Movies" },
  { id: "mini-golf", label: "Mini Golf" },
  { id: "escape-room", label: "Escape Room" },
  { id: "park", label: "Parks" },
  { id: "museum", label: "Museum" },
  { id: "skating", label: "Skating" },
];

export const DATE_NIGHT_TAGLINES = [
  "That's the date.",
  "Plans made. Go have fun.",
  "No more scrolling for ideas.",
  "Tonight has a plan now.",
  "Go make a memory.",
  "The hard part was deciding. Done.",
] as const;

export function dateNightMoodLabel(value: number): string {
  if (value < 34) return "Cozy";
  if (value < 67) return "Playful";
  return "Adventurous";
}

export function dateNightTypeLabel(types: readonly ConcreteDateNightType[]): string {
  if (types.includes("other-halloween-fall")) return "Other Halloween / Fall";
  if (types.includes("haunted-house")) return "Haunted House";
  if (types.includes("corn-maze")) return "Corn Maze";
  if (types.includes("pumpkin-patch")) return "Pumpkin Patch";
  if (types.includes("bowling")) return "Bowling";
  if (types.includes("arcade")) return "Arcade";
  if (types.includes("movies")) return "Movies";
  if (types.includes("mini-golf")) return "Mini Golf";
  if (types.includes("escape-room")) return "Escape Room";
  if (types.includes("park")) return "Park";
  if (types.includes("museum")) return "Museum";
  if (types.includes("skating")) return "Skating";
  return "Activity";
}
