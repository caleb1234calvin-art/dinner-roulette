import assert from 'node:assert/strict';
import test from 'node:test';
import fs from 'node:fs';
import vm from 'node:vm';
import { stripTypeScriptTypes } from 'node:module';
import { adaptOsmSeasonalMetadata as adapt } from './pr85/seasonal-osm-metadata.mjs';
const read=p=>fs.readFileSync(new URL('./main/'+p,import.meta.url),'utf8');
const clean=s=>stripTypeScriptTypes(s.replace(/^import .*;\n/gm,'').replace(/^export \{.*;\n/gm,'').replace(/\bexport /g,''));
const search=read('src/lib/date-night/search.ts');
// Exact source extraction, no rewritten classifier/mapper. Unrelated presentation/chain helpers are stubs.
const slice=search.slice(search.indexOf('function classify('),search.indexOf('\nasync function queryMirror'));
const scope={console,DEFAULT_LOCATION:{lat:37.0842,lon:-94.5133},isRetiredDateNightName:()=>false,isLikelyChain:()=>false,dateNightTypeLabel:x=>x.join(','),moodFor:()=>1};
vm.createContext(scope);
vm.runInContext(clean(read('src/lib/date-night/lifecycle.ts'))+'\n'+clean(read('src/lib/date-night/provider-evidence.ts'))+'\n'+clean(read('src/lib/location/model.ts'))+'\n'+clean(read('src/lib/restaurants/geo.ts'))+'\n'+clean(read('src/lib/date-night/query-plan.ts'))+'\n'+clean(slice)+'\nthis.api={seasonalTypes,providerLifecycle,normalizeLifecycleTags,elementToPlace,buildDateNightQuery};',scope);
const api=scope.api;
let id=1;
const row=(tags,extra={})=>({type:'node',id:id++,lat:10,lon:20,tags:{name:'Synthetic Site',...tags},...extra});
const cases=[
 ['explicit haunt',row({attraction:'haunted_house'})],
 ['explicit corn',row({attraction:'corn_maze'})],
 ['explicit pumpkin',row({attraction:'pumpkin_patch'})],
 ['maze crop fallback',row({leisure:'maze','maze:type':'hedge',crop:'corn'})],
 ['context prose',row({tourism:'farm',description:'Pumpkin picking and corn maze'})],
 ['negative prose',row({tourism:'farm',description:'Former corn maze'})],
 ['unrelated prose',row({shop:'gift',description:'Haunted house'})],
 ['historical only',row({'disused:attraction':'haunted_house'})],
 ['destroyed only',row({'destroyed:attraction':'haunted_house'})],
 ['active destroyed',row({attraction:'haunted_house',destroyed:'yes'})],
 ['false lifecycle suffix',row({attraction:'haunted_house','disused:attraction':'no'})],
 ['closed name',row({name:'Synthetic Closed Haunt',attraction:'haunted_house'})],
 ['missing name',row({name:'',attraction:'haunted_house'})],
 ['missing coordinates',row({attraction:'haunted_house'},{lat:undefined,lon:undefined})],
 ['invalid coordinates',row({attraction:'haunted_house'},{lat:100})],
 ['address variants',row({attraction:'haunted_house','addr:full':'12 Synthetic Road, Test Village'})],
 ['active historic maze',row({'disused:leisure':'maze','disused:crop':'corn'})],
 ['hours website',row({attraction:'haunted_house',opening_hours:'Mo-Su 09:00-17:00',website:'https://example.invalid/'})],
];
const results=cases.map(([label,element])=>({label,element,main:JSON.parse(JSON.stringify(api.elementToPlace(element,true))),pr85:adapt({elements:[element]})}));
fs.writeFileSync(new URL('./fixture-results.json',import.meta.url),JSON.stringify(results,null,2));
const get=label=>results.find(r=>r.label===label);
test('three explicit categories overlap, no added active classification',()=>{for(const label of ['explicit haunt','explicit corn','explicit pumpkin']){const r=get(label);assert.deepEqual(r.main.activityTypes,r.pr85.proposals[0].activityHints);}});
test('main recognizes context-qualified prose and independent crop fallback; PR85 drops both',()=>{for(const label of ['context prose','maze crop fallback']){const r=get(label);assert.ok(r.main.activityTypes.length);assert.equal(r.pr85.proposals.length,0);}});
test('both reject unrelated and negative prose',()=>{for(const label of ['negative prose','unrelated prose']){const r=get(label);assert.equal(r.main,null);assert.equal(r.pr85.proposals.length,0);}});
test('historical-only retained with separate historical hints; main already retains lifecycle record',()=>{const r=get('historical only');assert.equal(r.main.lifecycle,'disused');assert.deepEqual(r.pr85.proposals[0].activityHints,[]);assert.deepEqual(r.pr85.proposals[0].historicalCategoryHints,['haunted-house']);});
test('PR85 misses destroyed semantics and falsely flags disused:attraction=no',()=>{assert.equal(get('destroyed only').main.lifecycle,'permanently-closed');assert.equal(get('destroyed only').pr85.proposals.length,0);assert.deepEqual(get('active destroyed').pr85.proposals[0].mappedLifecycleConcerns,[]);assert.equal(get('active destroyed').main.lifecycle,'permanently-closed');assert.equal(get('false lifecycle suffix').main.lifecycle,undefined);assert.ok(get('false lifecycle suffix').pr85.proposals[0].mappedLifecycleConcerns.length);});
test('research envelope preserves rows mapper drops without eligibility',()=>{for(const label of ['closed name','missing name','missing coordinates']){const r=get(label);assert.equal(r.main,null);const p=r.pr85.proposals[0];assert.ok(p);assert.equal(p.publishable,false);assert.equal(p.year2026Verified,false);}});
test('PR85 rejects invalid coordinates into missing-location HOLD',()=>{const r=get('invalid coordinates');assert.equal(r.main.lat,100);assert.equal(r.pr85.proposals[0].approximateLocation,null);assert.ok(r.pr85.proposals[0].triage.reasons.includes('missing-mapped-location'));});
test('PR85 loses addr:full compared with main',()=>{assert.equal(get('address variants').main.address,'12 Synthetic Road, Test Village');assert.equal(get('address variants').pr85.proposals[0].proposedAddress,null);});
test('historical crop metadata retained by PR85 when mapper cannot reconstruct it',()=>{const r=get('active historic maze');assert.equal(r.main,null);assert.deepEqual(r.pr85.proposals[0].historicalCategoryHints,['corn-maze']);});
test('website and hours intentionally withheld; all proposals nonpublishable',()=>{assert.ok(get('hours website').main.website);for(const r of results)for(const p of r.pr85.proposals){assert.equal(p.sourceWebsite,null);assert.equal(p.openingHours,null);assert.equal(p.publishable,false);assert.equal(p.openNowEligible,false);}});
test('duplicate OSM identity and normalized names flag proposals instead of merging',()=>{const a=row({attraction:'haunted_house'});const r=adapt({elements:[a,a]});assert.equal(r.proposals.length,2);assert.ok(r.proposals.every(p=>p.triage.reasons.includes('conflicting-osm-identity')&&p.triage.reasons.includes('possible-mapped-identity-collision')));});
test('100-row input limit is coverage bound, not pagination or actual discovery gain',()=>{assert.equal(adapt({elements:Array.from({length:101},()=>row({attraction:'haunted_house'}))}).status,'coverage-incomplete');});
test('exact existing query already acquires explicit, prose, crop, lifecycle contexts with bounded radius',()=>{const q=api.buildDateNightQuery({activityTypes:['haunted-house','corn-maze','pumpkin-patch']},10,20,999999);fs.writeFileSync(new URL('./main-query.overpassql',import.meta.url),q);for(const s of ['out center tags','seasonal:description','seasonal:activities','["crop"~"^(corn|maize)$"]','destroyed:attraction','around:80467,10,20'])assert.ok(q.includes(s),s);});
