import fs from 'node:fs';
import assert from 'node:assert/strict';
import {appModuleLoader} from '../../scripts/test-support/load-app-module.mjs';
const output=process.cwd()+'/audit/production-loading-hang-audit-1-evidence/previous-main-probes-results.json';
process.chdir('/workspace/scratch/684a09290deb/previous-main');
const load=appModuleLoader(),results=[];
for(const [mode,file,fn,key] of [['Dinner','restaurants/search.ts','searchRestaurants','restaurants'],['Date Night','date-night/search.ts','searchDateNight','venues'],['Nightlife','nightlife/search.ts','searchNightlife','venues']]){
 const search=load('src/lib/'+file);let time=0,calls=[];Date.now=()=>1800000000000+time;const signals=new WeakMap();
 AbortSignal.timeout=ms=>{const c=new AbortController();signals.set(c.signal,{ms,c});return c.signal;};
 globalThis.fetch=async(url,options)=>{const {ms,c}=signals.get(options.signal);calls.push({url,timeoutMs:ms});time+=ms;c.abort(new DOMException('Audit timeout','TimeoutError'));throw c.signal.reason;};
 const result=await search[fn]({data:{lat:37.176447,lon:-94.310223,radiusMiles:15,spookySeasonEnabled:false}});
 assert.equal(time,mode==='Nightlife'?20000:88000);assert.equal(result.source,'fallback');
 results.push({mode,logicalElapsedMs:time,calls,source:result.source,count:result[key].length});
}
fs.writeFileSync(output,JSON.stringify(results,null,2));console.log('PASS: previous main has identical 88s / 88s / 20s timeout behavior');
