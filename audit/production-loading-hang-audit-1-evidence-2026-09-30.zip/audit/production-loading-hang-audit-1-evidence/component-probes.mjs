import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
import ts from 'typescript';
import React from 'react';
import {appModuleLoader} from '../../scripts/test-support/load-app-module.mjs';
const pkg=createRequire(import.meta.url),load=appModuleLoader();
const evidenceRoot=process.cwd()+'/audit/production-loading-hang-audit-1-evidence';
const previous=process.argv.includes('--previous');
if(previous)process.chdir('/workspace/scratch/684a09290deb/previous-main');
const output=[];
const flush=()=>new Promise(resolve=>setImmediate(resolve));
function deferred(){let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject};}
function harness(file,name,searchName){
 let states=[],cursor=0,effects=[],effectIndex=0,requests=[],setWrites=0;
 const store={location:{lat:37.176447,lon:-94.310223,label:'Carthage',source:'manual'},filters:{...load('src/lib/restaurants/types.ts').DEFAULT_FILTERS,openNowOnly:false},dateNightFilters:{...load('src/lib/date-night/types.ts').DEFAULT_DATE_NIGHT_FILTERS,openNowOnly:false},preferences:{},visits:[],exclusions:[],sessionShown:[],spookySeasonEnabled:false,pruneExpired:()=>{},setFilters:()=>{},setDateNightFilters:()=>{}};
 const require=specifier=>{
  if(specifier==='react')return {...React,useMemo:fn=>fn(),useState:init=>{const i=cursor++;if(!(i in states))states[i]=typeof init==='function'?init():init;return [states[i],value=>{setWrites++;states[i]=typeof value==='function'?value(states[i]):value}];},useEffect:(fn,deps)=>{const i=effectIndex++,old=effects[i];if(old&&deps.every((v,n)=>Object.is(v,old.deps[n])))return;old?.cleanup?.();effects[i]={deps,cleanup:fn()};}};
  if(specifier==='@/lib/store')return {useAppStore:s=>s(store)};
  if(specifier==='@/lib/date-night/use-clock')return {useDateNightClock:()=>new Date('2026-09-30T19:00:00Z')};
  if(specifier.endsWith('/search'))return {[searchName]:args=>{const d=deferred();requests.push({...d,args});return d.promise;}};
  if(specifier.startsWith('@/components/'))return new Proxy({},{get:(_t,key)=>{const leaf=props=>React.createElement('div',props,props.children);Object.defineProperty(leaf,'name',{value:String(key)});return leaf;}});
  if(specifier.startsWith('@/'))return load(path.join('src',specifier.slice(2)+'.ts'));
  return pkg(specifier);
 };
 const out=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText;
 const mod={exports:{}};new Function('require','module','exports',out)(require,mod,mod.exports);
 const render=()=>{cursor=0;effectIndex=0;return mod.exports[name]()};
 const collect=(node,kind)=>Array.isArray(node)?node.flatMap(n=>collect(n,kind)):node&&typeof node==='object'?[...(node.type?.name===kind?[node.props]:[]),...collect(node.props?.children,kind)]:[];
 const status=()=>{const tree=render();return {loading:collect(tree,'DiscoveryLoading').length>0,notices:collect(tree,'DiscoveryNotice').map(x=>({tone:x.tone,title:x.title})),writes:setWrites,requestCount:requests.length};};
 return {render,status,store,requests,dispose:()=>effects.forEach(e=>e.cleanup?.())};
}
for(const [mode,file,name,fn,key] of [
 ['Dinner','src/components/pick-home.tsx','PickHome','searchRestaurants','restaurants'],
 ['Date Night','src/components/date-night-home.tsx','DateNightHome','searchDateNight','venues'],
 ['Nightlife','src/components/nightlife-home.tsx','NightlifeHome','searchNightlife','venues']]){
 for(const scenario of ['success','fallback','error','abort-rejection','pending-transport','stale-resolves-after-new','stale-rejects-before-new','navigation']){
  const realTimeout=globalThis.setTimeout,realClearTimeout=globalThis.clearTimeout,realNow=Date.now;
  const timers=new Map();let virtual=0,timerId=0;
  if(scenario==='pending-transport'){
   globalThis.setTimeout=(fn,ms=0)=>{const id=++timerId;timers.set(id,{fn,at:virtual+ms});return id;};
   globalThis.clearTimeout=id=>timers.delete(id);Date.now=()=>1800000000000+virtual;
  }
  const h=harness(file,name,fn);assert.equal(h.status().loading,true);let before,after;
  const payload=source=>({[key]:[],source,warning:source==='fallback'?'Audit fallback':undefined});
  if(scenario==='success'||scenario==='fallback')h.requests[0].resolve(payload(scenario==='success'?'live':'fallback'));
  if(scenario==='error'||scenario==='abort-rejection')h.requests[0].reject(scenario==='error'?new Error('Audit transport 504'):new DOMException('Audit aborted','AbortError'));
  if(scenario==='pending-transport'){
   while([...timers.values()].some(t=>t.at<=600000)){
    const [id,timer]=[...timers].sort((a,b)=>a[1].at-b[1].at)[0];timers.delete(id);virtual=timer.at;timer.fn();await flush();
   }
   virtual=600000;await flush();after=h.status();after.watchdogTimersRegistered=timerId;
   assert.equal(after.loading,true);assert.equal(h.requests[0].args.signal,undefined);h.dispose();
  }else if(scenario.startsWith('stale-')){
   h.store.location={...h.store.location,lat:37.084184,lon:-94.513339};h.render();assert.equal(h.requests.length,2);
   if(scenario==='stale-resolves-after-new'){
    h.requests[1].resolve(payload('live'));await flush();assert.equal(h.status().loading,false);before=h.status();h.requests[0].resolve(payload('fallback'));await flush();after=h.status();assert.deepEqual(after,before);
   }else{
    h.requests[0].reject(new Error('stale error'));await flush();assert.equal(h.status().loading,true);assert.deepEqual(h.status().notices,[]);h.requests[1].resolve(payload('live'));await flush();after=h.status();assert.equal(after.loading,false);
   }
  }else if(scenario==='navigation'){
   h.dispose();before=h.status();h.requests[0].resolve(payload('live'));await flush();after=h.status();assert.equal(after.writes,before.writes);assert.equal(h.requests[0].args.signal,undefined);
   const next=harness(file,name,fn);next.render();next.requests[0].resolve(payload('live'));await flush();assert.equal(next.status().loading,false);next.dispose();
  }else{await flush();after=h.status();assert.equal(after.loading,false);}
  output.push({mode,scenario,passed:true,after,requestSignalProvided:Boolean(h.requests[0].args.signal),note:scenario==='pending-transport'?'Unresolved RPC stays loading after virtual timers advance 10 minutes; no client watchdog timer exists. Not a claim about a real browser TCP connection.':scenario==='navigation'?'Unmounted closure suppresses state writes, but does not abort RPC. Remount with settled RPC succeeds.':undefined});h.dispose();
  globalThis.setTimeout=realTimeout;globalThis.clearTimeout=realClearTimeout;Date.now=realNow;
 }
}
fs.writeFileSync(evidenceRoot+(previous?'/previous-component-probes-results.json':'/component-probes-results.json'),JSON.stringify(output,null,2));
console.log('PASS: '+output.length+' actual-component lifecycle scenarios; transport/hooks/leaf controls mocked; no browser/RPC acceptance implied');
