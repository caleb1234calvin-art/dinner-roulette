import fs from 'node:fs';
import assert from 'node:assert/strict';
import {appModuleLoader} from '../../scripts/test-support/load-app-module.mjs';
const load=appModuleLoader();
const searches=[['Dinner',load('src/lib/restaurants/search.ts').searchRestaurants,'restaurants'],['Date Night',load('src/lib/date-night/search.ts').searchDateNight,'venues'],['Nightlife',load('src/lib/nightlife/search.ts').searchNightlife,'venues']];
const out='audit/production-loading-hang-audit-1-evidence';
const originalFetch=globalThis.fetch, originalTimeout=AbortSignal.timeout, originalNow=Date.now;
const records=[];
const local={lat:37.176447,lon:-94.310223,radiusMiles:15,spookySeasonEnabled:false};
const far={lat:43.65348,lon:-79.38393,radiusMiles:15,spookySeasonEnabled:false};
// Accelerated deterministic clock: actual handlers; only network and clock are substituted.
for(const [mode,search,key] of searches){
 for(const scenario of ['abort-at-timeout','429','500','504','malformed','invalid-json','body-until-abort','first-timeout-second-success','empty-success']){
  let clock=0,calls=[]; const deadlines=new WeakMap();
  Date.now=()=>1800000000000+clock;
  AbortSignal.timeout=(ms)=>{const c=new AbortController();deadlines.set(c.signal,{ms,c});return c.signal;};
  globalThis.fetch=async(url,options)=>{
   const {ms,c}=deadlines.get(options.signal);calls.push({url,startMs:clock,timeoutMs:ms});
   const timeout=()=>{clock+=ms;c.abort(new DOMException('Timed out','TimeoutError'));throw c.signal.reason;};
   if(scenario==='abort-at-timeout'||(scenario==='first-timeout-second-success'&&calls.length===1))return timeout();
   if(scenario==='body-until-abort')return {ok:true,json:async()=>timeout()};
   if(['429','500','504'].includes(scenario))return new Response('',{status:Number(scenario)});
   if(scenario==='malformed')return Response.json({unexpected:true});
   if(scenario==='invalid-json')return new Response('not json',{status:200});
   return Response.json({elements:scenario==='empty-success'?[]:[{type:'node',id:99991,lat:local.lat,lon:local.lon,tags:{name:'Audit response',amenity:mode==='Dinner'?'restaurant':mode==='Nightlife'?'bar':'cinema'}}]});
  };
  const response=await search({data:local});
  records.push({mode,scenario,logicalElapsedMs:clock,calls,source:response.source,count:response[key].length,settled:true});
  assert.ok(response[key].length>0);
  if(scenario==='abort-at-timeout'||scenario==='body-until-abort')assert.equal(clock,mode==='Nightlife'?20000:88000);
  if(['429','500','504','malformed','invalid-json','abort-at-timeout','body-until-abort'].includes(scenario))assert.equal(response.source,'fallback');
 }
 Date.now=originalNow;AbortSignal.timeout=originalTimeout;
 globalThis.fetch=async()=>{throw new Error('upstream outage')};
 await assert.rejects(search({data:far})); records.push({mode,scenario:'outage-outside-saved-coverage',settled:true,result:'rejected error'});
}
Date.now=originalNow;AbortSignal.timeout=originalTimeout;
// Real clocks and native AbortSignal.timeout: all three modes concurrently, no real network.
const timingCalls=[];
globalThis.fetch=(url,opts)=>new Promise((resolve,reject)=>{
 const rec={url,start:new Date().toISOString(),body:new URLSearchParams(opts.body).get('data').slice(0,130)}; timingCalls.push(rec);
 opts.signal.addEventListener('abort',()=>{rec.abortedAt=new Date().toISOString();reject(opts.signal.reason)},{once:true});
});
const keepAlive=setInterval(()=>{},1000);
await Promise.all(searches.map(async([mode,search,key])=>{const start=performance.now();const result=await search({data:local});const rec={mode,scenario:'native-real-time-all-mirrors-abort',elapsedMs:performance.now()-start,source:result.source,count:result[key].length}; records.push(rec);console.log(JSON.stringify(rec));fs.writeFileSync(`${out}/provider-probes-results.json`,JSON.stringify({records,timingCalls},null,2));}));
clearInterval(keepAlive);globalThis.fetch=originalFetch;
console.log('PASS: '+records.length+' provider scenario groups');
