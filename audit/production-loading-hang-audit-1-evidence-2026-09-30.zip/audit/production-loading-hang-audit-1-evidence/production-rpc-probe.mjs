import fs from 'node:fs';
import {toJSONAsync,fromCrossJSON} from 'seroval';
const target='https://dinner-roulette-chi.vercel.app/_serverFn/';
const cases=[
 ['Dinner','98643e628e23400f0229d25a4e6b98ee2ba6cb3e2d9b5a7d0d1cf9f1a3f0571a',15,false],
 ['Date Night ordinary','608c34308c11ff23ec95123e13645a3f5e73aa32bd73cdd2742409e0d31b0253',15,false],
 ['Date Night seasonal','608c34308c11ff23ec95123e13645a3f5e73aa32bd73cdd2742409e0d31b0253',50,true],
 ['Nightlife','19f4a1d3d706509159de41d77dab873c4c976e6d810eeb0596ed0165be4cdde7',15,false]
];
const results=[];
for(const [mode,id,radiusMiles,spookySeasonEnabled] of cases){
 const row={mode,url:target+id,start:new Date().toISOString(),data:{lat:37.176447,lon:-94.310223,radiusMiles,spookySeasonEnabled}};const start=performance.now();
 try{
  const options={method:'POST',headers:{'x-tsr-serverFn':'true','content-type':'application/json','accept':'application/json'},body:JSON.stringify(await toJSONAsync({data:row.data})),signal:AbortSignal.timeout(100000)};
  row.request={method:options.method,headers:options.headers,body:options.body};
  const r=await fetch(row.url,options);row.httpStatus=r.status;row.headersAt=new Date().toISOString();row.responseHeaders=Object.fromEntries(r.headers);
  const raw=await r.text();row.raw=raw;const response=r.headers.get('x-tss-serialized')?fromCrossJSON(JSON.parse(raw)):JSON.parse(raw);
  row.elapsedMs=performance.now()-start;row.settledAt=new Date().toISOString();row.response=response;
 }catch(e){row.elapsedMs=performance.now()-start;row.error=String(e);row.cause=String(e.cause??'');}
 results.push(row);fs.writeFileSync('audit/production-loading-hang-audit-1-evidence/production-rpc-results.json',JSON.stringify(results,null,2));
 console.log(JSON.stringify({...row,response:row.response?{keys:Object.keys(row.response),resultSource:row.response?.result?.source,resultCount:(row.response?.result?.restaurants??row.response?.result?.venues??[]).length}:undefined}));
 if(row.error&& !row.httpStatus)break;
}
